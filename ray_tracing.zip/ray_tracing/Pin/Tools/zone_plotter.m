
%Takes an already made grid and plots the distribution of several variables
%inside a specific zone.

addpath(strcat(pwd,'..\\Functions\\General_Functions'))
addpath(strcat(pwd,'..\\Functions\\Case_Functions'))
addpath(strcat(pwd,'..\\Functions\\Solvers'))

i = 6;
j = 6;
N = 101;
quad_rule = 'Gauss';
xs2 = 10;
source_gp = [1,1];
r_s = [0.0,0.0];

dx = grid(i,j).edge_lengths(1);
dy = grid(i,j).edge_lengths(2);

x = linspace(grid(i,j).location(1)-dx/2, grid(i,j).location(1)+dx/2, N);
y = linspace(grid(i,j).location(2)-dy/2, grid(i,j).location(2)+dy/2, N);

[X,Y] = meshgrid(x,y);
%[X, Y, WX, WY] = quad_points_cent(grid,i,j,N,quad_rule);
    
sigma_bar = zeros(N);
opt_depth = zeros(N);
flux = zeros(N);
xs = zeros(N);
N_abs = zeros(N);

for m = 1:N
    for n = 1:N
        r = [X(m,n), Y(m,n)];
        R = sqrt(sum((r-r_s).^2));
        sigma_bar(m,n) = average_xs(r,r_s,source_gp,grid,i,j);
        opt_depth(m,n) = sigma_bar(m,n)*R;
        flux(m,n) = exp(-opt_depth(m,n))/R;
        xs(m,n) = xs2;
        N_abs(m,n) = flux(m,n)*xs(m,n)*dx*dy;
    end
end


for i = 1:N
    X(i,N+1) = X(i,N) + dx/N;
    Y(i,N+1) = Y(i,N);
    opt_depth(i,N+1) = opt_depth(i,N);
    flux(i,N+1) = flux(i,N);
    N_abs(i,N+1) = N_abs(i,N);
    xs(i,N+1) = xs(i,N);
    sigma_bar(i,N+1) = sigma_bar(i,N);
end
for j = 1:N
    X(N+1,j) = X(N,j);
    Y(N+1,j) = Y(N,j) + dy/N;
    opt_depth(N+1,j) = opt_depth(N,j);
    flux(N+1,j) = flux(N,j);
    N_abs(N+1,j) = N_abs(N,j);
    xs(N+1,j) = xs(N,j);
    sigma_bar(N+1,j) = sigma_bar(N,j);
end
X(N+1,N+1) = X(N,N+1);
Y(N+1,N+1) = Y(N+1,N);
opt_depth(N+1,N+1) = opt_depth(N+1,N);
flux(N+1,N+1) = flux(N+1,N);
N_abs(N+1,N+1) = N_abs(N+1,N);
xs(N+1,N+1) = xs(N+1,N);
sigma_bar(N+1,N+1) = sigma_bar(N+1,N);


figsize = [50 50 800 600];
fontsize = 15;
gridlines = 0;
n = 1;


figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X,Y,xs);
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title('Cross Section',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X,Y,opt_depth);
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title('Optical Depth',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')
set(gca,'ColorScale','log')
mm = [10^floor(log10(min(min(opt_depth)))),10^ceil(log10(max(max(opt_depth))))];
%caxis(mm);
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X,Y,sigma_bar);
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title('Average Cross Section to Zone Center',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')
set(gca,'ColorScale','log')
mm = [10^floor(log10(min(min(sigma_bar))) - 0.1),10^ceil(log10(max(max(sigma_bar))))];
%caxis(mm);
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X,Y,flux);
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title('Flux [n/cm^2*s]',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')
set(gca,'ColorScale','log')
% mm = [10^floor(log10(min(min(flux)))),10^ceil(log10(max(max(flux))))];
% if min(min(flux)) > 0.0
%     caxis(mm);
% else
%     fprintf('\nNegative flux values for %d,%d zones and %d rays\n', N, N, N); 
% end
n = n+1;

flux_diag = zeros(N,1);
flux_x = zeros(N,1);
flux_rot = rot90(flux(1:end-1,1:end-1));
od_diag = zeros(N,1);
od_x = zeros(N,1);
od_rot = rot90(opt_depth(1:end-1,1:end-1));
sb_diag = zeros(N,1);
sb_x = zeros(N,1);
sb_rot = rot90(sigma_bar(1:end-1,1:end-1));
for i = 1:N
    for j = 1:N
        if i == j
            flux_diag(i) = flux_rot(i,j);
            od_diag(i) = od_rot(i,j);
            sb_diag(i) = sb_rot(i,j);
        end
        if j == floor(N/2)
            flux_x(i) = flux(i,j);
            od_x(i) = opt_depth(i,j);
            sb_x(i) = sigma_bar(i,j);
        end
    end
end

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1:N,flux_diag,'-')
title('Flux Along Perpendicular Diagonal',' ','Fontsize',18)
xlabel('i')
ylabel('Flux')
xlim([1,N])
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(x,flux_x,'-')
title('Flux Along x',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('Flux')
xlim([x(1),x(end)])
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1:N,od_diag,'-')
title('OD Along Perpendicular Diagonal',' ','Fontsize',18)
xlabel('i')
ylabel('OD')
xlim([1,N])
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(x,od_x,'-')
title('OD Along x',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('OD')
xlim([x(1),x(end)])
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1:N,sb_diag,'-')
title('Sigma Bar Along Perpendicular Diagonal',' ','Fontsize',18)
xlabel('i')
ylabel('Sigma Bar')
xlim([1,N])
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(x,sb_x,'-')
title('Sigma Bar Along x',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('sigma bar')
xlim([x(1),x(end)])
n = n+1;

rmpath(strcat(pwd,'..\\Functions\\General_Functions'))
rmpath(strcat(pwd,'..\\Functions\\Case_Functions'))
rmpath(strcat(pwd,'..\\Functions\\Solvers'))


