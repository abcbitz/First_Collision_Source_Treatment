clear 

addpath(strcat(pwd,'\\..\\Functions\\General_Functions'))
addpath(strcat(pwd,'\\..\\Functions\\Case_Functions'))
addpath(strcat(pwd,'\\..\\Functions\\Solvers'))

%trapz yields expected order of convergence (global - 2)
%Gauss yields order of roughly - 2*N
% - Error estimates for Gauss are weird and depend on the function being integrated
% - Gauss doesn't work the same way as other integration methods. 

quad_rule = 'Gauss';
%quad_rule = 'Trapz';
max_divs = 10;
N = 3;
sigma_a = 10.0;
r_s = [0.0,0.0];
dim = [1.0,1.0];
%dim = [0.1,0.1];
%dim = [0.4,0.2];
edge_length = 0.1;
x = 0.4;
y = 0.2;

trapz_flag = 0;
if strcmp(quad_rule,'Gauss')
    [nodes,weights] = lgwt(N,1,-1);
    nodes = transpose(nodes);
    weights = transpose(-weights);
    
elseif strcmp(quad_rule,'Gauss-Lobatto')
    [nodes,weights] = lglnodes(N-1);
    nodes = transpose(flip(nodes));
    weights = transpose(weights);
    
else
    nodes = linspace(-1,1,N);
    weights = ones(1,N);
    trapz_flag = 1;
end


%Face 4
n = [0,1];
total_current = zeros(max_divs,1);
locs = zeros((max_divs-1)*N,1);
currents = zeros((max_divs-1)*N,1);
c = 1;
for N_sub = 1:max_divs
    ints = transpose(linspace(x-edge_length/2,x+edge_length/2,N_sub+1));
    approx = zeros(N_sub,1);
    
    for m = 1:length(ints)-1
        sub_nodes = 1/2*(1+nodes)*(ints(m+1) - ints(m)) + ints(m);
        sub_weights = 1/2*weights*(ints(m+1) - ints(m));
        f_eval = zeros(1,length(sub_nodes));
        for k = 1:length(sub_nodes)
            if n(2) == 0
                r = [x,sub_nodes(k)];
            else
                r = [sub_nodes(k),y];
            end
            R = sqrt(sum((r-r_s).^2));
            opt_depth = R*sigma_a;
            %f_eval(k) = exp(-opt_depth)/R * dot(n,(r-r_s)/R);
            %f_eval(k) = sub_nodes(k)^2*exp(sub_nodes(k)^1);
            f_eval(k) = cos(sub_nodes(k))*exp(sub_nodes(k)^1);
            
            if N_sub == max_divs
                locs(c) = sub_nodes(k);
                currents(c) = f_eval(k);
                c = c + 1;
            end
        end
        
        if trapz_flag == 0
            approx(m) = sum(sub_weights.*f_eval)/(ints(m+1) - ints(m));
        else
            approx(m) = trapz(sub_nodes,f_eval)/(ints(m+1) - ints(m));
        end        
    end
    
    total_current(N_sub) = sum(approx.*(ints(2:end)-ints(1:end-1)))/edge_length;
end



%Reference Solution
N = 10;
trapz_flag = 0;
if strcmp(quad_rule,'Gauss')
    [nodes,weights] = lgwt(N,1,-1);
    nodes = transpose(nodes);
    weights = transpose(-weights);
    
elseif strcmp(quad_rule,'Gauss-Lobatto')
    [nodes,weights] = lglnodes(N-1);
    nodes = transpose(flip(nodes));
    weights = transpose(weights);
    
else
    nodes = linspace(-1,1,N);
    weights = ones(1,N);
    trapz_flag = 1;
end

N_sub = 100;
ints = transpose(linspace(x-edge_length/2,x+edge_length/2,N_sub+1));
approx = zeros(N_sub,1);

for m = 1:length(ints)-1
    sub_nodes = 1/2*(1+nodes)*(ints(m+1) - ints(m)) + ints(m);
    sub_weights = 1/2*weights*(ints(m+1) - ints(m));
    f_eval = zeros(1,length(sub_nodes));
    for k = 1:length(sub_nodes)
        if n(2) == 0
            r = [x,sub_nodes(k)];
        else
            r = [sub_nodes(k),y];
        end
        R = sqrt(sum((r-r_s).^2));
        opt_depth = R*sigma_a;
        %f_eval(k) = exp(-opt_depth)/R * dot(n,(r-r_s)/R);
        %f_eval(k) = sub_nodes(k)^2*exp(sub_nodes(k)^1);
        f_eval(k) = cos(sub_nodes(k))*exp(sub_nodes(k)^1);
    end
    
    if trapz_flag == 0
        approx(m) = sum(sub_weights.*f_eval)/(ints(m+1) - ints(m));
    else
        approx(m) = trapz(sub_nodes,f_eval)/(ints(m+1) - ints(m));
    end
end

total_current_ref = sum(approx.*(ints(2:end)-ints(1:end-1)))/edge_length;


dx = edge_length./(1:max_divs);
error_4 = abs(total_current-total_current_ref)/total_current_ref;

m4 = (log10(error_4(2))-log10(error_4(1)))/(log10(dx(2))-log10(dx(1)));
fprintf('\nm(2-1) = %.5f\n',m4)

m4 = (log10(error_4(3))-log10(error_4(1)))/(log10(dx(3))-log10(dx(1)));
fprintf('m(3-1) = %.5f\n',m4)

m4 = (log10(error_4(end-1))-log10(error_4(1)))/(log10(dx(end-1))-log10(dx(1)));
fprintf('m(end-1) = %.5f\n',m4)

m4 = (log10(error_4(round(end/2)+1))-log10(error_4(round(end/2)-1)))/(log10(dx(round(end/2)+1))-log10(dx(round(end/2)-1)));
fprintf('m(mid) = %.5f\n',m4)

m4 = (log10(error_4(end-1))-log10(error_4(end-3)))/(log10(dx(end-1))-log10(dx(end-3)));
fprintf('m(end) = %.5f\n',m4)

f = 1;
figsize = [50 50 800 600];
fontsize = 15;
figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(dx,error_4,'x-')
xlabel('dx [cm]')
ylabel('Relative Error')
title(sprintf('Relative Error'))
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(locs,currents,'x-')
xlabel('x [cm]')
ylabel('Current')
title(sprintf('Current - y = %.2f',y))
f = f + 1;

rmpath(strcat(pwd,'\\..\\Functions\\General_Functions'))
rmpath(strcat(pwd,'\\..\\Functions\\Case_Functions'))
rmpath(strcat(pwd,'\\..\\Functions\\Solvers'))





