%starting at 13, odds are using ray trace, evens are integral
%For plotting, in repeated_plotter, set rem to 1 if just eliminating src
%zone, otherwise set to 2

set_num = 2;
plot_num = 300;

%wp - zones
%4x4 - 4 12 20 28 36 44 52 60
%5x5 - 5 15 25 35 45 55 
%6x6 - 6 18 30 42 54 

%N_zones = [18,30,42,54,66];
%N_zones = [15,25,35,45,55];
%N_zones = [10,15,20,25,30,35];
N_zones = [20,28,36,44,52,60,68];
%N_zones = [12,20,28,36,44,52];
%N_zones = [10,15,20];
N_rays_surf = [2,4,6,8,10,12]; %number of rays cast (interp points) for surf method
N_rays_int = [2,3,4,5,6]; %number of rays cast for inter method in each dim
%N_rays_surf = [2,4]; %number of rays cast (interp points) for surf method
%N_rays_int = [2,3]; %number of rays cast for inter method in each dim
%N_rays_surf = [4]; %number of rays cast (interp points) for surf method
%N_rays_int = [3]; %number of rays cast for inter method in each dim

q = 1.0e6;
L = 1.0;
H = 1.0;
source_loc = [0,0];

local_conv = [28,4,12];    %[N_zones,i,j]
%local_conv = [30,4,12];    %[N_zones,i,j]

wp = 4;
exclude = 20;

global use_func
use_func = 0;

max_error = 1e-15;
N_rays_true = 3;
max_divs = 30;

include_all_plots = 0;
save_all_plots = 0;
save_plots = 1;

load_soln = 0;
load_run_data = 0;
load_set_data = 1;


dim = [L,H];

warning('off','MATLAB:MKDIR:DirectoryExists')
warning('off','MATLAB:polyfit:RepeatedPointsOrRescale')

%meth = {'Gauss','Gauss_Lobatto','Trapz'};
meth = {'Gauss'};

addpath(strcat(pwd,'\\Functions\\General_Functions'))
addpath(strcat(pwd,'\\Functions\\Case_Functions'))
addpath(strcat(pwd,'\\Functions\\Solvers'))

for k = 1:length(meth)
    quad_method = meth{k};
    name = sprintf('.\\Runs\\Set_%i\\%s',set_num,quad_method);
    
    if load_set_data == 1
        load(sprintf('%s\\data',name))
        
    else
        if load_soln == 0
            mkdir(sprintf('%s\\true_solutions',name))
        end
    
        absorb_error_tot_surf = zeros(length(N_zones),length(N_rays_surf));
        absorb_error_avg_surf = zeros(length(N_zones),length(N_rays_surf));
        absorb_error_med_surf = zeros(length(N_zones),length(N_rays_surf));
        absorb_error_L1_surf = zeros(length(N_zones),length(N_rays_surf));
        absorb_error_L2_surf = zeros(length(N_zones),length(N_rays_surf));
        absorb_error_L1_rem_surf = zeros(length(N_zones),length(N_rays_surf));
        absorb_error_L2_rem_surf = zeros(length(N_zones),length(N_rays_surf));
        leakage_error_surf = zeros(length(N_zones),length(N_rays_surf));
        cons_error_surf = zeros(length(N_zones),length(N_rays_surf));
        local_error_surf = zeros(length(N_rays_surf),1);
        wp_rel_error_surf = zeros(length(N_zones),length(N_rays_surf),wp,wp);
        wp_L1_error_surf = zeros(length(N_zones),length(N_rays_surf));
        for i = 1:length(N_zones)
            if load_soln == 0
                %if you use multiple quad_rules, it will rerun the true sol
                %for each rule, despite them all using Gauss-Kron
                repeated(N_zones(i), N_rays_surf(1), 'solver_surf_adapt', q, dim, source_loc, quad_method, include_all_plots, save_all_plots, local_conv, name, load_run_data, exclude, wp, max_error, N_rays_true, max_divs);
            end
            for j = 1:length(N_rays_surf)
                if N_zones(i) == local_conv(1)
                    [absorb_error_tot_surf(i,j),absorb_error_avg_surf(i,j),absorb_error_med_surf(i,j),absorb_error_L1_surf(i,j),absorb_error_L2_surf(i,j),absorb_error_L1_rem_surf(i,j),absorb_error_L2_rem_surf(i,j),leakage_error_surf(i,j),cons_error_surf(i,j),local_error_surf(j),wp_rel_error_surf(i,j,:,:),wp_L1_error_surf(i,j)] = repeated(N_zones(i), N_rays_surf(j), 'solver_surf', q, dim, source_loc, quad_method, include_all_plots, save_all_plots, local_conv, name, load_run_data, exclude, wp, max_error, N_rays_true, max_divs);
                else
                    [absorb_error_tot_surf(i,j),absorb_error_avg_surf(i,j),absorb_error_med_surf(i,j),absorb_error_L1_surf(i,j),absorb_error_L2_surf(i,j),absorb_error_L1_rem_surf(i,j),absorb_error_L2_rem_surf(i,j),leakage_error_surf(i,j),cons_error_surf(i,j),~,wp_rel_error_surf(i,j,:,:),wp_L1_error_surf(i,j)] = repeated(N_zones(i), N_rays_surf(j), 'solver_surf', q, dim, source_loc, quad_method, include_all_plots, save_all_plots, local_conv, name, load_run_data, exclude, wp, max_error, N_rays_true, max_divs);
                end
                movefile(sprintf('.\\Runs\\%s\\XY_%i_%i__N_%i','solver_surf',N_zones(i),N_zones(i),N_rays_surf(j)), sprintf('%s\\%s\\XY_%i_%i__N_%i',name,'solver_surf',N_zones(i),N_zones(i),N_rays_surf(j)))
            end
        end

        absorb_error_tot_int = zeros(length(N_zones),length(N_rays_int));
        absorb_error_avg_int = zeros(length(N_zones),length(N_rays_int));
        absorb_error_med_int = zeros(length(N_zones),length(N_rays_int));
        absorb_error_L1_int = zeros(length(N_zones),length(N_rays_int));
        absorb_error_L2_int = zeros(length(N_zones),length(N_rays_int));
        absorb_error_L1_rem_int = zeros(length(N_zones),length(N_rays_int));
        absorb_error_L2_rem_int = zeros(length(N_zones),length(N_rays_int));
        leakage_error_int = zeros(length(N_zones),length(N_rays_int));
        cons_error_int = zeros(length(N_zones),length(N_rays_int));
        local_error_int = zeros(length(N_rays_int),1);
        wp_rel_error_int = zeros(length(N_zones),length(N_rays_int),wp,wp);
        wp_L1_error_int = zeros(length(N_zones),length(N_rays_int));
        for i = 1:length(N_zones)
            for j = 1:length(N_rays_int)
                if N_zones(i) == local_conv(1)
                    [absorb_error_tot_int(i,j),absorb_error_avg_int(i,j),absorb_error_med_int(i,j),absorb_error_L1_int(i,j),absorb_error_L2_int(i,j),absorb_error_L1_rem_int(i,j),absorb_error_L2_rem_int(i,j),leakage_error_int(i,j),cons_error_int(i,j),local_error_int(j),wp_rel_error_int(i,j,:,:),wp_L1_error_int(i,j)] = repeated(N_zones(i), N_rays_int(j), 'solver_int', q, dim, source_loc, quad_method, include_all_plots, save_all_plots, local_conv, name, load_run_data, exclude, wp, max_error, N_rays_true, max_divs);
                else
                    [absorb_error_tot_int(i,j),absorb_error_avg_int(i,j),absorb_error_med_int(i,j),absorb_error_L1_int(i,j),absorb_error_L2_int(i,j),absorb_error_L1_rem_int(i,j),absorb_error_L2_rem_int(i,j),leakage_error_int(i,j),cons_error_int(i,j),~,wp_rel_error_int(i,j,:,:),wp_L1_error_int(i,j)] = repeated(N_zones(i), N_rays_int(j), 'solver_int', q, dim, source_loc, quad_method, include_all_plots, save_all_plots, local_conv, name, load_run_data, exclude, wp, max_error, N_rays_true, max_divs);
                end
                movefile(sprintf('.\\Runs\\%s\\XY_%i_%i__N_%i','solver_int',N_zones(i),N_zones(i),N_rays_int(j)), sprintf('%s\\%s\\XY_%i_%i__N_%i',name,'solver_int',N_zones(i),N_zones(i),N_rays_int(j)))
            end
        end
        
        save(sprintf('%s\\data',name))
    end
    
    repeated_plotter_loglog(N_zones,N_rays_surf,N_rays_int,absorb_error_tot_surf,...
        absorb_error_tot_int,absorb_error_avg_surf,absorb_error_avg_int,...
        absorb_error_med_surf,absorb_error_med_int,absorb_error_L1_surf,absorb_error_L1_int,...
        absorb_error_L2_surf,absorb_error_L2_int,absorb_error_L1_rem_surf,absorb_error_L1_rem_int,...
        absorb_error_L2_rem_surf,absorb_error_L2_rem_int,leakage_error_surf,leakage_error_int,...
        cons_error_surf,cons_error_int,local_error_surf,local_error_int,...
        wp_rel_error_surf,wp_rel_error_int,wp_L1_error_surf,wp_L1_error_int,...
        local_conv,name,save_plots,plot_num,exclude,max_error,dim);
end


rmpath(strcat(pwd,'\\Functions\\General_Functions'))
rmpath(strcat(pwd,'\\Functions\\Case_Functions'))
rmpath(strcat(pwd,'\\Functions\\Solvers'))



