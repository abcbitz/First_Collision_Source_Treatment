function tot_num_rays = total_rays(N_rays,N_zones,method)

tot_num_rays = zeros(1);

%for GL and trapz

if method == 1  %interior point
    for n = 1:length(N_zones)
        for i = 1:N_zones(n)
            for j = 1:N_zones(n)
                tot_num_rays(n) = tot_num_rays(n) + 4/4; %corners
                tot_num_rays(n) = tot_num_rays(n) + (N_rays - 2)*4/2; %sides
                tot_num_rays(n) = tot_num_rays(n) + (N_rays - 2)^2; %inside
            end
        end
    end
    
else    %surface
    for n = 1:length(N_zones)
        for i = 1:N_zones(n)
            for j = 1:N_zones(n)
                tot_num_rays(n) = tot_num_rays(n) + 4/4; %corners
                tot_num_rays(n) = tot_num_rays(n) + (N_rays - 2)*4/2; %interior sides
            end
        end
    end
end
    
    
    