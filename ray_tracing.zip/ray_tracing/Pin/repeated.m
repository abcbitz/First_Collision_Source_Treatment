function [absorb_error_tot,absorb_error_avg,absorb_error_med,absorb_error_L1,absorb_error_L2,...
    absorb_error_L1_rem,absorb_error_L2_rem,leakage_error,cons_error,loc_error,wp_rel_error,wp_L1] = ...
    repeated(N_zones,N_rays,solver,q,dim,source_loc,quad_rule,include_plots,...
    save_plots,local_conv,folder,load_run_data,exclude,wp,max_error,N_rays_true,max_divs)

num_zones = [N_zones,N_zones];

neg_fix = 0;  %this variable isn't relevant for these tests

tic
fprintf('\n--------------------------------------------\n')
fprintf('\nSolver = %s\n',solver)
fprintf('Quad Rule = %s\n',quad_rule)
fprintf('Number of zones per dimension = %d\n',num_zones(1))
fprintf('Total number of zones = %d\n',prod(num_zones))
fprintf('Number of rays per dimension = %.0f\n',N_rays)


if strcmp(solver,'solver_surf_adapt') == 1
    grid_true = looper(num_zones,dim,N_rays_true,q,source_loc,solver,quad_rule,neg_fix,max_divs,max_error);
    save(sprintf('%s\\true_solutions\\true_soln__%d_zones.mat',folder,num_zones(1)),'grid_true')
    return %not sure if this will work
    
else
    load(sprintf('%s\\true_solutions\\true_soln__%d_zones.mat',folder,num_zones(1)),'grid_true')
    if load_run_data == 1
        load(sprintf('%s\\%s\\XY_%i_%i__N_%i\\data',folder,solver,N_zones,N_zones,N_rays),'grid')
    else
        grid = looper(num_zones,dim,N_rays,q,source_loc,solver,quad_rule,neg_fix,max_divs,max_error);
    end
    
    [absorb_error_tot,absorb_error_avg,absorb_error_med,absorb_error_L1,absorb_error_L2,...
        absorb_error_L1_rem,absorb_error_L2_rem,leakage_error,cons_error,wp_rel_error,wp_L1] = ...
        plotter(grid,grid_true,q,source_loc,dim,N_rays,solver,include_plots,save_plots,exclude,wp);
end
   

%Add eps to everything so values equaling zero still show up on log plots
absorb_error_tot = absorb_error_tot + eps;
absorb_error_L1 = absorb_error_L1 + eps;
absorb_error_L2 = absorb_error_L2 + eps;
absorb_error_L1_rem = absorb_error_L1_rem + eps;
absorb_error_L2_rem = absorb_error_L2_rem + eps;
leakage_error = leakage_error + eps;
cons_error = cons_error + eps;
wp_rel_error = wp_rel_error + eps;
wp_L1 = wp_L1 + eps;

loc_error = 0;
if local_conv(1) == N_zones
    loc_error = abs(grid(local_conv(2),local_conv(3)).avg_N_absorb-grid_true(local_conv(2),local_conv(3)).avg_N_absorb)/grid_true(local_conv(2),local_conv(3)).avg_N_absorb;
end


toc

