function repeated_plotter_loglog(N_zones,N_rays_surf,N_rays_int,absorb_error_tot_surf,...
        absorb_error_tot_int,absorb_error_avg_surf,absorb_error_avg_int,absorb_error_med_surf,...
        absorb_error_med_int,absorb_error_L1_surf,absorb_error_L1_int,absorb_error_L2_surf,...
        absorb_error_L2_int,absorb_error_L1_rem_surf,absorb_error_L1_rem_int,...
        absorb_error_L2_rem_surf,absorb_error_L2_rem_int,leakage_error_surf,...
        leakage_error_int,cons_error_surf,cons_error_int,local_error_surf,...
        local_error_int,wp_rel_error_surf,wp_rel_error_int,wp_L1_error_surf,...
        wp_L1_error_int,local_conv,folder,savePlots,plot_num,rem,true_error,dim)

    
%close all
mkdir(folder)

leg_rays = cell(length(N_rays_int)+length(N_rays_surf),1);
for i = 1:length(N_rays_int)
    leg_rays{i} = sprintf('Int - %d rays/zone', N_rays_int(i)^2);
end
for i = 1:length(N_rays_surf)
    %this value could be a multitude of things...
    leg_rays{i+length(N_rays_int)} = sprintf('Surf - %d rays/zone', 2*N_rays_surf(i)); 
    %leg_rays{i+length(N_rays_int)} = sprintf('Surf - %d rays/zone', 4*N_rays_surf(i)); 
end
leg_rays{end+1} = 'True Soln Tolerance';

leg_zones = cell(length(N_zones)*2,1);
for i = 1:length(N_zones)
    leg_zones{i} = sprintf('Int - %d zones/dim', N_zones(i));
end
for i = 1:length(N_zones)
    leg_zones{i+length(N_zones)} = sprintf('Surf - %d zones/dim', N_zones(i));
end


%Plotting attributes
figsize = [50 50 800 700];
fontsize = 15;
%n = 200;
n = plot_num;

%Total Error
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, absorb_error_tot_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(1./N_zones, absorb_error_tot_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(1./N_zones, absorb_error_tot_surf(:,i), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title('Total Absorption Error vs \Deltax','','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('Total Relative Absorption Error')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\tot_absorp_error_vs_delta_x__loglog',folder),savePlots)
n = n+1;

%Average Error
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, absorb_error_avg_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(1./N_zones, absorb_error_avg_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(1./N_zones, absorb_error_avg_surf(:,i), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title('Average Absorption Error vs \Deltax','','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('Average Relative Absorption Error')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\avg_absorp_error_vs_delta_x__loglog',folder),savePlots)
n = n+1;

%Median Error
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, absorb_error_med_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(1./N_zones, absorb_error_med_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(1./N_zones, absorb_error_med_surf(:,i), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title('Median Absorption Error vs \Deltax','','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('Median Relative Absorption Error')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\med_absorp_error_vs_delta_x__loglog',folder),savePlots)
n = n+1;

%L1 Error
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, absorb_error_L1_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(1./N_zones, absorb_error_L1_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(1./N_zones, absorb_error_L1_surf(:,i), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title('L1 Absorption Error vs \Deltax','','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('L1 Relative Absorption Error')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\L1_absorp_error_vs_delta_x__loglog',folder),savePlots)
n = n+1;

%L2 Error
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, absorb_error_L2_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(1./N_zones, absorb_error_L2_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(1./N_zones, absorb_error_L2_surf(:,i), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title('L2 Absorption Error vs \Deltax','','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('L2 Relative Absorption Error')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\L2_absorp_error_vs_delta_x__loglog',folder),savePlots)
n = n+1;

%L1 Error - Zones near src removed
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, absorb_error_L1_rem_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(1./N_zones, absorb_error_L1_rem_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(1./N_zones, absorb_error_L1_rem_surf(:,i), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title(sprintf('L1 Absorption Error vs dx \n(Zones near src removed)'),'','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('L1 Relative Absorption Error')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\L1_absorp_error_rem_vs_delta_x__loglog_%i',folder,rem),savePlots)
n = n+1;

%L2 Error - Zones near src removed
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, absorb_error_L2_rem_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(1./N_zones, absorb_error_L2_rem_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(1./N_zones, absorb_error_L2_rem_surf(:,i), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title(sprintf('L2 Absorption Error vs dx \n(Zones near src removed)'),'','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('L2 Relative Absorption Error')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\L2_absorp_error_rem_vs_delta_x__loglog_%i',folder,rem),savePlots)
n = n+1;

%Leakage Error
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, leakage_error_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(1./N_zones, leakage_error_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(1./N_zones, leakage_error_surf(:,i), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title('Total Leakage Error vs \Deltax','','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('$\frac{|N_{leak,calc}-N_{leak,true}|}{N_{leak,true}}$','interpreter','latex')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\tot_leakage_error_vs_delta_x__loglog',folder),savePlots)
n = n+1;

%Conservation Error
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, cons_error_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(1./N_zones, cons_error_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(1./N_zones, cons_error_surf(:,i), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title('Total Conservation Error vs \Deltax','','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('$\frac{N_{src}-N_{leak}-N_{abs}}{N_{src}}$','interpreter','latex')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\cons_error_vs_delta_x__loglog',folder),savePlots)
n = n+1;

%Local Error
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(N_rays_int.^2, local_error_int, '-x')
hold on
loglog(N_rays_surf*2, local_error_surf, '-o')
hold off
title(sprintf('Absorption Error vs Number of Rays at (%d,%d)\n N_{zones} = [%d,%d]',local_conv(2),local_conv(3),local_conv(1),local_conv(1)),'','Fontsize',18)
xlabel('Number of Rays per Zone')
ylabel('Relative Absorption Error')
grid on
legend('Int','Surf','Location','southoutside')
save_plot(figure(n),sprintf('%s\\local_error_vs_N_rays__loglog',folder),savePlots)
n = n+1;

%Watchpoints
wp = size(wp_rel_error_surf,3);
dx = dim(1)/wp;
x_wp = zeros(wp,1);
for i = 1:wp
    x_wp(i) = (i-0.5)*dx;
end
dy = dim(2)/wp;
y_wp = zeros(wp,1);
for i = 1:wp
    y_wp(i) = (i-0.5)*dy;
end

wp_error_int = zeros(length(N_zones),length(N_rays_int));
wp_error_surf = zeros(length(N_zones),length(N_rays_surf));
for i = 1:length(N_zones)
    for j = 1:length(N_rays_int)
        wp_error_int(i,j) = trapz(y_wp,trapz(x_wp,reshape(wp_rel_error_int(i,j,:,:),wp,wp,1,1),2));
    end
    for j = 1:length(N_rays_surf)
        wp_error_surf(i,j) = trapz(y_wp,trapz(x_wp,reshape(wp_rel_error_surf(i,j,:,:),wp,wp,1,1),2));
    end
end
        
%wp integrated
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, wp_error_int(:,1), '-x')
hold on
for k = 2:length(N_rays_int)
    loglog(1./N_zones, wp_error_int(:,k), '-x')
end
for k = 1:length(N_rays_surf)
    loglog(1./N_zones, wp_error_surf(:,k), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title(sprintf('Integrated Absorption Error vs dx \n(wp integrated)'),'','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('Integrated Absorption Error')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\wp_integ_error_vs_delta_x__loglog',folder),savePlots)
n = n+1;

%wp L1
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones, wp_L1_error_int(:,1), '-x')
hold on
for k = 2:length(N_rays_int)
    loglog(1./N_zones, wp_L1_error_int(:,k), '-x')
end
for k = 1:length(N_rays_surf)
    loglog(1./N_zones, wp_L1_error_surf(:,k), '-o')
end
loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
hold off
title(sprintf('L1 Absorption Error vs dx'),'','Fontsize',18)
xlabel('\Deltax [cm]')
ylabel('L1 Relative Absorption Error')
grid on
legend(leg_rays,'Location','southoutside','NumColumns',3)
save_plot(figure(n),sprintf('%s\\wp_L1_error_vs_delta_x__loglog',folder),savePlots)
n = n+1;

fprintf('\nSlopes for Interior Point Method:\n')
for i = 1:length(N_rays_int)
    slope = abs(log10(wp_L1_error_int(2,i)) - log10(wp_L1_error_int(1,i))) / abs(log10(1/N_zones(2)) - log10(1/N_zones(1)));
    fprintf('m_%i = %.5f\n',N_rays_int(i)^2,slope)
end
fprintf('\nSlopes for Surface Method:\n')
for i = 1:length(N_rays_surf)
    %slope = abs(log10(wp_L1_error_surf(2,i)) - log10(wp_L1_error_surf(1,i))) / abs(log10(1/N_zones(2)) - log10(1/N_zones(1)));
    slope = abs(log10(wp_L1_error_surf(3,i)) - log10(wp_L1_error_surf(2,i))) / abs(log10(1/N_zones(3)) - log10(1/N_zones(2)));
    fprintf('m_%i = %.5f\n',N_rays_surf(i)*2,slope)
end

%Relative error at wp
for i = 1:wp
    for j = 1:wp
        figure(n)
        set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
        loglog(1./N_zones, wp_rel_error_int(:,1,i,j), '-x')
        hold on
        for k = 2:length(N_rays_int)
            loglog(1./N_zones, wp_rel_error_int(:,k,i,j), '-x')
        end
        for k = 1:length(N_rays_surf)
            loglog(1./N_zones, wp_rel_error_surf(:,k,i,j), '-o')
        end
        loglog(1./N_zones, ones(length(N_zones),1)*true_error,'--','color','black')
        hold off
        title(sprintf('Absorption Error vs dx at (x,y) = (%.3f,%.3f)',x_wp(i),y_wp(j)),'','Fontsize',18)
        xlabel('\Deltax [cm]')
        ylabel('Relative Absorption Error')
        grid on
        legend(leg_rays,'Location','southoutside','NumColumns',3)
        save_plot(figure(n),sprintf('%s\\wp_rel_error_vs_dx__%i_%i',folder,i,j),savePlots)
        n = n + 1;
    end
end


%Efficiency Diagrams
%Need to use true ray counts (optimized)
%Could eventually switch to cpu time instead - no idea how to do this
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(N_zones.^2*N_rays_int(1)^2, absorb_error_L1_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(N_zones.^2*N_rays_int(i)^2, absorb_error_L1_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(N_zones.^2*N_rays_surf(i)*2, absorb_error_L1_surf(:,i), '-o')
end
hold off
title('L1 Efficiency Diagram for Various Ray Counts')
xlabel('Total Rays')
ylabel('L1 Relative Absorption Error')
legend(leg_rays,'Location','southoutside','NumColumns',3)
grid on
save_plot(figure(n),sprintf('%s\\efficiency_diagram_L1',folder),savePlots)
n = n+1;

figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(N_zones.^2*N_rays_int(1)^2, absorb_error_L1_rem_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(N_zones.^2*N_rays_int(i)^2, absorb_error_L1_rem_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(N_zones.^2*N_rays_surf(i)*2, absorb_error_L1_rem_surf(:,i), '-o')
end
hold off
title(sprintf('L1 Efficiency Diagram for Various Ray Counts \n(Zones near src removed)'),'','Fontsize',18)
xlabel('Total Rays')
ylabel('L1 Relative Absorption Error')
legend(leg_rays,'Location','southoutside','NumColumns',3)
grid on
save_plot(figure(n),sprintf('%s\\efficiency_diagram_L1_%i',folder,rem),savePlots)
n = n+1;

figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(N_zones.^2*N_rays_int(1)^2, wp_L1_error_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(N_zones.^2*N_rays_int(i)^2, wp_L1_error_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(N_zones.^2*N_rays_surf(i)*2, wp_L1_error_surf(:,i), '-o')
end
hold off
title(sprintf('L1 Efficiency Diagram for Various Ray Counts'),'','Fontsize',18)
xlabel('Total Rays')
ylabel('L1 Relative Absorption Error')
legend(leg_rays,'Location','southoutside','NumColumns',3)
grid on
save_plot(figure(n),sprintf('%s\\efficiency_diagram_L1_wp',folder),savePlots)
n = n+1;

figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(N_rays_int(1)^2./(dim(1)./N_zones).^2, wp_L1_error_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(N_rays_int(i)^2./(dim(1)./N_zones).^2, wp_L1_error_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(N_rays_surf(i)*2./(dim(1)./N_zones).^2, wp_L1_error_surf(:,i), '-o')
end
hold off
title(sprintf('L1 Efficiency Diagram for Various Ray Counts'),'','Fontsize',18)
xlabel('Number of Rays per cm^2')
ylabel('L1 Relative Absorption Error')
legend(leg_rays,'Location','southoutside','NumColumns',3)
grid on
save_plot(figure(n),sprintf('%s\\L1_efficiency_diagram_wp_2',folder),savePlots)
n = n+1;

%wp_ind = [1,1; 1,4; 4,5; 5,6; 6,6;];
wp_ind = [1,1; 1,3; 3,4; 4,4;];
for k = 1:size(wp_ind,1)
    figure(n)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    loglog(N_rays_int(1)^2./(dim(1)./N_zones).^2, wp_rel_error_int(:,1,wp_ind(k,1),wp_ind(k,2)), '-x')
    hold on
    for i = 2:length(N_rays_int)
        loglog(N_rays_int(i)^2./(dim(1)./N_zones).^2, wp_rel_error_int(:,i,wp_ind(k,1),wp_ind(k,2)), '-x')
    end
    for i = 1:length(N_rays_surf)
        loglog(N_rays_surf(i)*2./(dim(1)./N_zones).^2, wp_rel_error_surf(:,i,wp_ind(k,1),wp_ind(k,2)), '-o')
    end
    hold off
    title(sprintf('Relative Error Efficiency Diagram for Various Ray Counts \nat (x,y) = (%.3f,%.3f)',x_wp(wp_ind(k,1)),y_wp(wp_ind(k,2))),'','Fontsize',18)
    xlabel('Number of Rays per cm^2')
    ylabel('Relative Absorption Error')
    legend(leg_rays,'Location','southoutside','NumColumns',3)
    grid on
    save_plot(figure(n),sprintf('%s\\efficiency_diagram_wp_%i_%i',folder,wp_ind(k,1),wp_ind(k,2)),savePlots)
    n = n+1;
end      
              
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(N_zones.^2*N_rays_int(1)^2, absorb_error_L2_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(N_zones.^2*N_rays_int(i)^2, absorb_error_L2_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(N_zones.^2*N_rays_surf(i)*2, absorb_error_L2_surf(:,i), '-o')
end
hold off
title('L2 Efficiency Diagram for Various Ray Counts')
xlabel('Total Rays')
ylabel('L2 Relative Absorption Error')
legend(leg_rays,'Location','southoutside','NumColumns',3)
grid on
save_plot(figure(n),sprintf('%s\\efficiency_diagram_L2',folder),savePlots)
n = n+1;

figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(N_zones*N_rays_int(1).^2, absorb_error_L2_rem_int(:,1), '-x')
hold on
for i = 2:length(N_rays_int)
    loglog(N_zones*N_rays_int(i).^2, absorb_error_L2_rem_int(:,i), '-x')
end
for i = 1:length(N_rays_surf)
    loglog(N_zones*N_rays_surf(i)*2, absorb_error_L2_rem_surf(:,i), '-o')
end
hold off
title(sprintf('L2 Efficiency Diagram for Various Ray Counts \n(Zones near src removed)'),'','Fontsize',18)
xlabel('Total Rays')
ylabel('L2 Relative Absorption Error')
legend(leg_rays,'Location','southoutside','NumColumns',3)
grid on
save_plot(figure(n),sprintf('%s\\efficiency_diagram_L2_%i',folder,rem),savePlots)
n = n+1;


%For heat maps
N_zones(end+1) = N_zones(end) + N_zones(end) - N_zones(end-1);
N_rays_int(end+1) = N_rays_int(end) + N_rays_int(end) - N_rays_int(end-1);
N_rays_surf(end+1) = N_rays_surf(end) + N_rays_surf(end) - N_rays_surf(end-1);
absorb_error_L1_int(end+1,:) = absorb_error_L1_int(end,:);
absorb_error_L1_int(:,end+1) = absorb_error_L1_int(:,end);
absorb_error_L1_surf(end+1,:) = absorb_error_L1_surf(end,:);
absorb_error_L1_surf(:,end+1) = absorb_error_L1_surf(:,end);
wp_L1_error_int(end+1,:) = wp_L1_error_int(end,:);
wp_L1_error_int(:,end+1) = wp_L1_error_int(:,end);
wp_L1_error_surf(end+1,:) = wp_L1_error_surf(end,:);
wp_L1_error_surf(:,end+1) = wp_L1_error_surf(:,end);

mm = [1e-15,1e-4];

%Scaling plots - L1
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
[X,Y] = meshgrid(N_zones.^2,N_rays_int.^2);
pcolor(X,Y,transpose(absorb_error_L1_int))
title('L1 Error Scaling for IP Method')
xlabel('Number of Zones')
ylabel('Rays per Zone')
colormap turbo
colorbar('Location','westoutside')
set(gca,'ColorScale','log')
%mm = [10^floor(log10(min(min(absorb_error_L1_int)))),10^floor(log10(max(max(absorb_error_L1_int))))];
caxis(mm);
save_plot(figure(n),sprintf('%s\\L1_error_scaling_IP',folder),savePlots)
set(gca,'ColorScale','log') %it resets the scaling after saving for some reason
caxis(mm);
n = n+1;

figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
[X,Y] = meshgrid(N_zones.^2,N_rays_surf*2);
pcolor(X,Y,transpose(absorb_error_L1_surf))
title('L1 Error Scaling for Surface Method')
xlabel('Number of Zones')
ylabel('Rays per Zone')
colormap turbo
colorbar('Location','westoutside')
set(gca,'ColorScale','log')
%mm = [10^floor(log10(min(min(absorb_error_L1_surf)))),10^floor(log10(max(max(absorb_error_L1_surf))))];
caxis(mm);
save_plot(figure(n),sprintf('%s\\L1_error_scaling_surf',folder),savePlots)
set(gca,'ColorScale','log')
caxis(mm);
n = n+1;

%Scaling plots - L1 - wp
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
[X,Y] = meshgrid(N_zones.^2,N_rays_int.^2);
pcolor(X,Y,transpose(wp_L1_error_int))
title('L1 Error Scaling for IP Method')
xlabel('Number of Zones')
ylabel('Rays per Zone')
colormap turbo
colorbar('Location','westoutside')
set(gca,'ColorScale','log')
%mm = [10^floor(log10(min(min(wp_L1_error_int)))),10^floor(log10(max(max(wp_L1_error_int))))];
caxis(mm);
save_plot(figure(n),sprintf('%s\\L1_error_scaling_IP_wp',folder),savePlots)
set(gca,'ColorScale','log')
caxis(mm);
n = n+1;

figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
[X,Y] = meshgrid(N_zones.^2,N_rays_surf*2);
pcolor(X,Y,transpose(wp_L1_error_surf))
title('L1 Error Scaling for Surface Method')
xlabel('Number of Zones')
ylabel('Rays per Zone')
colormap turbo
colorbar('Location','westoutside')
set(gca,'ColorScale','log')
%mm = [10^floor(log10(min(min(wp_L1_error_surf)))),10^floor(log10(max(max(wp_L1_error_surf))))];
caxis(mm);
save_plot(figure(n),sprintf('%s\\L1_error_scaling_surf_wp',folder),savePlots)
set(gca,'ColorScale','log')
caxis(mm);
n = n+1;

