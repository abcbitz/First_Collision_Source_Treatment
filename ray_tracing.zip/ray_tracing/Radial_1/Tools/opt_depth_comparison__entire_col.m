clear

N_zones = 20;
N = 4;
N_hr = 500;
dim = [1.0,1.0];
r_s = [0.0,0.0];

[i,face,f] = deal(10,3,1);
%[i,face,f] = deal(6,3,7);

addpath(strcat(pwd,'\\..\\Functions\\General_Functions'))
addpath(strcat(pwd,'\\..\\Functions\\Case_Functions'))
addpath(strcat(pwd,'\\..\\Functions\\Solvers'))

global use_func
use_func = 0;

grid = build_grid([N_zones,N_zones],dim);

dx = 1/N_zones;
dy = 1/N_zones;

source_gp = source_zone(r_s,grid);

n_vec = [-1,0];
if face == 2
    n_vec = [0,-1];
elseif face == 3
    n_vec = [1,0];
elseif face == 4
    n_vec = [0,1];
end

r_hr_all = [];
sigma_bar_hr_all = [];
opt_depth_hr_all = [];
current_hr_all = [];

r_all = [];
sigma_bar_all = [];
opt_depth_all = [];
current_all = [];

%For face 3
for j = 1:N_zones
    %High accuracy xs
    [r_hr,~] = quad_points_surf(grid,i,j,face,N_hr,'Trapz');
    R_hr = sqrt(sum((r_hr - r_s).^2,2));
    sigma_bar_hr = zeros(N_hr,1);
    for n = 1:N_hr
        sigma_bar_hr(n) = average_xs(r_hr(n,:),r_s,source_gp,grid,i,j);
    end
    opt_depth_hr = sigma_bar_hr.*R_hr;
    current_hr = exp(-opt_depth_hr)./R_hr .* sum(n_vec.*(r_hr-r_s)./R_hr,2);
    
    %Specific points
    [r,~] = quad_points_surf(grid,i,j,face,N,'Gauss');
    R = sqrt(sum((r - r_s).^2,2));
    sigma_bar = zeros(N,1);
    for n = 1:N
        sigma_bar(n) = average_xs(r(n,:),r_s,source_gp,grid,i,j);
    end
    opt_depth = sigma_bar.*R;
    current = exp(-opt_depth)./R .* sum(n_vec.*(r-r_s)./R,2);
    
    %Store it all
    r_hr_all(end+1:end+N_hr) = r_hr(:,2);
    sigma_bar_hr_all(end+1:end+N_hr) = sigma_bar_hr;
    opt_depth_hr_all(end+1:end+N_hr) = opt_depth_hr;
    current_hr_all(end+1:end+N_hr) = current_hr;
    
    r_all(end+1:end+N) = r(:,2);
    sigma_bar_all(end+1:end+N) = sigma_bar;
    opt_depth_all(end+1:end+N) = opt_depth;
    current_all(end+1:end+N) = current;
end


figsize = [50 50 800 600];
fontsize = 15;
gridlines = 1;

[X,Y] = meshgrid(linspace(0,dim(1),N_zones+1),linspace(0,dim(2),N_zones+1));
xs = zeros(N_zones+1);
for m = 1:N_zones
    for n = 1:N_zones
        xs(m,n) = grid(m,n).sigma_a;
    end
end

figure(100)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X,Y,xs);
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title('Cross Section',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')

    
xlab = 'x [cm]';
if face == 1 || face == 3
    xlab = 'y [cm]';
end


m = f;
figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(r_hr_all,sigma_bar_hr_all,'-')
hold on 
plot(r_all,sigma_bar_all,'x')
hold off
xlabel(xlab)
ylabel('Average Cross Section')
title(sprintf('Average Cross Section - Face %i - Row/Column %i',face,i))
m = m+1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(r_hr_all,opt_depth_hr_all,'-')
hold on 
plot(r_all,opt_depth_all,'x')
hold off
xlabel(xlab)
ylabel('Optical Depth')
title(sprintf('Optical Depth - Face %i - Row/Column %i',face,i))
m = m+1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(r_hr_all,current_hr_all,'-')
hold on 
plot(r_all,current_all,'x')
hold off
xlabel(xlab)
ylabel('Current')
title(sprintf('Current - Face %i - Row/Column %i',face,i))
m = m+1;

N_pts = 3;
highest_deriv = 2;
deriv_sb = zeros(length(sigma_bar_hr_all)-N_pts+1,1);
deriv_cur = zeros(length(current_hr_all)-N_pts+1,1);
h = r_hr_all(2) - r_hr_all(1);
for k = 1:highest_deriv
    if rem(k,2) == 1
        coeffs = transpose(GenerateCentralDiffsCoefs(k,N_pts-k));
    else
        coeffs = transpose(GenerateCentralDiffsCoefs(k,N_pts-k+1));
    end
    for p = 1:(length(sigma_bar_hr_all)-N_pts+1) % - 1?
        deriv_sb(p) = 1/h^k*sum(coeffs.*sigma_bar_hr_all(p:p+N_pts-1));
        deriv_cur(p) = 1/h^k*sum(coeffs.*current_hr_all(p:p+N_pts-1));
    end
    
    figure(m)
    clf(m)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    plot(r_hr_all(1:(length(sigma_bar_hr_all)-N_pts+1)),deriv_sb)
    xlabel(xlab)
    ylabel('Derivative of Sigma Bar')
    title(sprintf('Derivative %i of Sigma bar - Face %i - Row/Column %i',k,face,i))
    m = m + 1;
    
    figure(m)
    clf(m)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    plot(r_hr_all(1:(length(sigma_bar_hr_all)-N_pts+1)),deriv_cur)
    xlabel(xlab)
    ylabel('Derivative of Current')
    title(sprintf('Derivative %i of Current - Face %i - Row/Column %i',k,face,i))
    m = m + 1;
end


use_func = 1;

sigma_bar_hr_all = [];
opt_depth_hr_all = [];
current_hr_all = [];

sigma_bar_all = [];
opt_depth_all = [];
current_all = [];

%For face 4
for j = 1:N_zones
    %High accuracy xs
    [r_hr,~] = quad_points_surf(grid,i,j,face,N_hr,'Trapz');
    R_hr = sqrt(sum((r_hr - r_s).^2,2));
    sigma_bar_hr = zeros(N_hr,1);
    for n = 1:N_hr
        sigma_bar_hr(n) = average_xs(r_hr(n,:),r_s,source_gp,grid,i,j);
    end
    opt_depth_hr = sigma_bar_hr.*R_hr;
    current_hr = exp(-opt_depth_hr)./R_hr .* sum(n_vec.*(r_hr-r_s)./R_hr,2);
    
    %Specific points
    [r,~] = quad_points_surf(grid,i,j,face,N,'Gauss');
    R = sqrt(sum((r - r_s).^2,2));
    sigma_bar = zeros(N,1);
    for n = 1:N
        sigma_bar(n) = average_xs(r(n,:),r_s,source_gp,grid,i,j);
    end
    opt_depth = sigma_bar.*R;
    current = exp(-opt_depth)./R .* sum(n_vec.*(r-r_s)./R,2);
    
    %Store it all
    sigma_bar_hr_all(end+1:end+N_hr) = sigma_bar_hr;
    opt_depth_hr_all(end+1:end+N_hr) = opt_depth_hr;
    current_hr_all(end+1:end+N_hr) = current_hr;
    
    sigma_bar_all(end+1:end+N) = sigma_bar;
    opt_depth_all(end+1:end+N) = opt_depth;
    current_all(end+1:end+N) = current;
end

y = linspace(dx,dim(1)-dx,N_zones-1);

m = f;

figure(m)
hold on 
plot(r_hr_all,sigma_bar_hr_all,'-')
plot(r_all,sigma_bar_all,'x')
xline(y,'--','color','black')
hold off
m = m+1;

figure(m)
hold on 
plot(r_hr_all,opt_depth_hr_all,'-')
plot(r_all,opt_depth_all,'x')
xline(y,'--','color','black')
hold off
m = m+1;

figure(m)
hold on 
plot(r_hr_all,current_hr_all,'-')
plot(r_all,current_all,'x')
xline(y,'--','color','black')
hold off
m = m+1;

for k = 1:highest_deriv
    if rem(k,2) == 1
        coeffs = transpose(GenerateCentralDiffsCoefs(k,N_pts-k));
    else
        coeffs = transpose(GenerateCentralDiffsCoefs(k,N_pts-k+1));
    end
    for p = 1:(length(sigma_bar_hr_all)-N_pts+1) % - 1?
        deriv_sb(p) = 1/h^k*sum(coeffs.*sigma_bar_hr_all(p:p+N_pts-1));
        deriv_cur(p) = 1/h^k*sum(coeffs.*current_hr_all(p:p+N_pts-1));
    end
    
    figure(m)
    hold on
    plot(r_hr_all(1:(length(sigma_bar_hr_all)-N_pts+1)),deriv_sb)
    xline(y,'--','color','black')
    hold off
    m = m + 1;
    
    figure(m)
    hold on
    plot(r_hr_all(1:(length(sigma_bar_hr_all)-N_pts+1)),deriv_cur)
    xline(y,'--','color','black')
    hold off
    m = m + 1;
end


rmpath(strcat(pwd,'\\..\\Functions\\General_Functions'))
rmpath(strcat(pwd,'\\..\\Functions\\Case_Functions'))
rmpath(strcat(pwd,'\\..\\Functions\\Solvers'))





