
max_er = 1e-12;
max_divs = 30;

q = 1e6;

for n = 10:5:40
    grid = build_grid([n,n],[1,1]);
    grid_true = true_solution(grid,q,[0,0],max_er,max_divs);
    save(sprintf('true_solutions_2\\true_soln__%d_zones',n),'grid_true');
end
