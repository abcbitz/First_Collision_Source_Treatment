
%Looks at how the refining the mesh and the xs (since its a function)
%effects the convergence of the answer at the far edge
%To use, need to change build_grid so its 1D (only dependent on x)

%roughly second order convergence in one dimension

L = 1.0;
%r_s = [0.0,0.0];
r_s = [0.0,L/2];
r = [L,L/2];
N_max = 400;
N_rays = 12;

addpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
addpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
addpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))

R = sqrt(sum((r - r_s).^2));
f = @(x) 5 + 5*cos(x/sqrt(2)*pi + pi);
OD_true = integral(f,0.0,L,'RelTol',1e-15);
%OD_true = integral(f,0.0,R,'RelTol',1e-15);

x = zeros(N_max,1);
xs = zeros(N_max,1);
OD = zeros(N_max,1);
c = 1;
for N_zones = 1:N_max
    grid = build_grid([N_zones,1],[L,L]);
    OD(c) = average_xs(r,r_s,[1,1],grid,N_zones,1)*R;
    
    if N_zones == N_max
        for i = 1:N_zones
            x(i) = grid(i,1).location(1);
            xs(i) = grid(i,1).sigma_a;
        end
    end
    
    c = c + 1;
end

xs_true = f(x);
avg_current_true = exp(-OD_true);
avg_current = exp(-OD);

error = abs(OD - OD_true)/OD_true;
conv = abs(OD(2:end) - OD(1:end-1))./OD(2:end);

error_curr = abs(avg_current - avg_current_true)/avg_current_true;
conv_curr = abs(avg_current(2:end) - avg_current(1:end-1))./avg_current(2:end);

dx = L./(1:N_max);

figsize = [50 50 800 700];
fontsize = 15;

n = 1;
figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
%semilogy(1:N_max,error,'-')
loglog(dx,error,'-')
xlabel('dx')
ylabel('Relative Error')
title('Opt Depth Rel Error')
n = n + 1;

figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
%semilogy(2:N_max,conv,'-')
loglog(dx(2:end),conv,'-')
xlabel('dx')
ylabel('i - (i-1)')
title('Opt Depth Convergence')
n = n + 1;


figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
%semilogy(1:N_max,error_curr,'-')
loglog(dx,error_curr,'-')
xlabel('dx')
ylabel('Relative Error')
title('Current Rel Error')
n = n + 1;

figure(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
%semilogy(2:N_max,conv_curr,'-')
loglog(dx(2:end),conv_curr,'-')
xlabel('dx')
ylabel('i - (i-1)')
title('Current Convergence')
n = n + 1;


rmpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
rmpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
rmpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))


