
zones = [1,2,3,4];
colors = {'#0072BD','#D95319','#7E2F8E','#77AC30','#A2142F','#EDB120','#4DBEEE','blue','red','magenta'};
names = {'i=1','i=2','i=3','i=4','i=5','i=6'};
pts = 100;
r_s = [0,0];
source_gp = [1,1];
q = 1e6;


y = zeros(size(grid(1,1).opt_depth_3,1), size(grid,2));
sigma_bar_3 = zeros(size(grid(1,1).opt_depth_3,1), size(grid,2));
opt_depth_3 = zeros(size(grid(1,1).opt_depth_3,1), size(grid,2));
current_3 = zeros(size(grid(1,1).opt_depth_3,1), size(grid,2));

y_hr = zeros(pts,size(grid,2));
sigma_bar_3_hr = zeros(pts,size(grid,2));
opt_depth_3_hr = zeros(pts,size(grid,2));
current_3_hr = zeros(pts,size(grid,2));

i = 2;
for j = 1:size(grid,2)
    for k = 1:size(grid(1,1).opt_depth_3,1)
        y(k,j) = grid(i,j).opt_depth_3(k,2);
        opt_depth_3(k,j) = grid(i,j).opt_depth_3(k,3);
        sigma_bar_3(k,j) = grid(i,j).sigma_bar_3(k,3);
        current_3(k,j) = grid(i,j).currents_3(k,3);
    end
    
    y1 = grid(i,j).location(2) - grid(i,j).edge_lengths(2)/2;
    y2 = grid(i,j).location(2) + grid(i,j).edge_lengths(2)/2;
    y_hr(:,j) = linspace(y1,y2,pts);
    for k = 1:pts
        r = [grid(i,j).location(1)+grid(i,j).edge_lengths(1)/2, y_hr(k,j)];
        R_y = norm(r);
        sigma_bar_3_hr(k,j) = average_xs(r,r_s,source_gp,grid,i,j);
        opt_depth_3_hr(k,j) = sigma_bar_3_hr(k,j)*R_y;
        current_3_hr(k,j) = q*exp(-opt_depth_3_hr(k,j))/R_y * dot([1,0],(r-r_s)/R_y);
    end
end


x = zeros(size(grid(1,1).opt_depth_4,1), size(grid,1));
sigma_bar_4 = zeros(size(grid(1,1).opt_depth_4,1), size(grid,1));
opt_depth_4 = zeros(size(grid(1,1).opt_depth_4,1), size(grid,1));
current_4 = zeros(size(grid(1,1).opt_depth_4,1), size(grid,1));

x_hr = zeros(pts,size(grid,1));
sigma_bar_4_hr = zeros(pts,size(grid,1));
opt_depth_4_hr = zeros(pts,size(grid,1));
current_4_hr = zeros(pts,size(grid,1));

j = 5;
for i = 1:size(grid,1)
    for k = 1:size(grid(1,1).opt_depth_4,1)
        x(k,i) = grid(i,j).opt_depth_4(k,1);
        opt_depth_4(k,i) = grid(i,j).opt_depth_4(k,3);
        sigma_bar_4(k,i) = grid(i,j).sigma_bar_4(k,3);
        current_4(k,i) = grid(i,j).currents_4(k,3);
    end
    
    x1 = grid(i,j).location(1) - grid(i,j).edge_lengths(1)/2;
    x2 = grid(i,j).location(1) + grid(i,j).edge_lengths(1)/2;
    x_hr(:,i) = linspace(x1,x2,pts);
    for k = 1:pts
        r = [x_hr(k,i), grid(i,j).location(2)+grid(i,j).edge_lengths(2)/2];
        R_x = norm(r);
        sigma_bar_4_hr(k,i) = average_xs(r,r_s,source_gp,grid,i,j);
        opt_depth_4_hr(k,i) = sigma_bar_4_hr(k,i)*R_x;
        current_4_hr(k,i) = q*exp(-opt_depth_4_hr(k,i))/R_x * dot([0,1],(r-r_s)/R_x);
    end
end


figsize = [50 50 800 600];
fontsize = 15;
gridlines = 1;
m = 10;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(y_hr(:,1),sigma_bar_3_hr(:,1),'color',colors{1})
hold on 
for i = 2:size(grid,1)
    plot(y_hr(:,i),sigma_bar_3_hr(:,i),'color',colors{i})
end
for i = 1:size(grid,1)
    plot(y(:,i),sigma_bar_3(:,i),'x','color',colors{i})
end
hold off
%legend(names)
xlabel('y')
ylabel('Sigma bar')
title('Average Cross Section')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(y_hr(:,1),opt_depth_3_hr(:,1),'color',colors{1})
hold on 
for i = 2:size(grid,1)
    plot(y_hr(:,i),opt_depth_3_hr(:,i),'color',colors{i})
end
for i = 1:size(grid,1)
    plot(y(:,i),opt_depth_3(:,i),'x','color',colors{i})
end
hold off
%legend(names)
xlabel('y')
ylabel('Optical Depth')
title('Optical Depth')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(y_hr(:,1),current_3_hr(:,1),'color',colors{1})
hold on 
for i = 2:size(grid,1)
    plot(y_hr(:,i),current_3_hr(:,i),'color',colors{i})
end
for i = 1:size(grid,1)
    plot(y(:,i),current_3(:,i),'x','color',colors{i})
end
hold off
%legend(names)
xlabel('y')
ylabel('Current')
title('Current')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(x_hr(:,1),sigma_bar_4_hr(:,1),'color',colors{1})
hold on 
for i = 2:size(grid,1)
    plot(x_hr(:,i),sigma_bar_4_hr(:,i),'color',colors{i})
end
for i = 1:size(grid,1)
    plot(x(:,i),sigma_bar_4(:,i),'x','color',colors{i})
end
hold off
%legend(names)
xlabel('x')
ylabel('Sigma bar')
title('Average Cross Section')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(x_hr(:,1),opt_depth_4_hr(:,1),'color',colors{1})
hold on 
for i = 2:size(grid,1)
    plot(x_hr(:,i),opt_depth_4_hr(:,i),'color',colors{i})
end
for i = 1:size(grid,1)
    plot(x(:,i),opt_depth_4(:,i),'x','color',colors{i})
end
hold off
%legend(names)
xlabel('x')
ylabel('Optical Depth')
title('Optical Depth')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(x_hr(:,1),current_4_hr(:,1),'color',colors{1})
hold on 
for i = 2:size(grid,1)
    plot(x_hr(:,i),current_4_hr(:,i),'color',colors{i})
end
for i = 1:size(grid,1)
    plot(x(:,i),current_4(:,i),'x','color',colors{i})
end
hold off
%legend(names)
xlabel('x')
ylabel('Current')
title('Current')
m = m + 1;



x_mid = zeros(size(grid,1),1);
x_right = zeros(size(grid,1),1);
R_x = zeros(size(grid,1),1);
err_3_x = zeros(size(grid,1),1);
err_4_x = zeros(size(grid,1),1);
err_tot_x = zeros(size(grid,1),1);
for i = 1:size(grid,1)
    x_mid(i) = grid(i,j).location(1);
    x_right(i) = grid(i,j).location(1) + grid(i,j).edge_lengths(1)/2;
    r = [grid(i,j).location(1),grid(i,j).location(2)];
    R_x(i) = norm(r);
    err_3_x(i) = abs(grid(i,j).total_current(3)-grid_true(i,j).total_current(3))/grid_true(i,j).total_current(3);
    err_4_x(i) = abs(grid(i,j).total_current(4)-grid_true(i,j).total_current(4))/grid_true(i,j).total_current(4);
    err_tot_x(i) = abs(grid(i,j).avg_N_absorb-grid_true(i,j).avg_N_absorb)/grid_true(i,j).avg_N_absorb;
end

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(x_mid,err_3_x(:,1),'-x','color',colors{1})
xlabel('x')
ylabel('Relative Error')
title('Current Error - Face 3')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(x_mid,err_4_x(:,1),'-x','color',colors{1})
xlabel('x')
ylabel('Relative Error')
title('Current Error - Face 4')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(x_mid,err_tot_x(:),'-x','color',colors{1})
xlabel('x')
ylabel('Relative Error')
title('Absorption Error')
m = m + 1;


y_mid = zeros(size(grid,2),1);
y_top = zeros(size(grid,2),1);
R_y = zeros(size(grid,2),1);
err_3_y = zeros(size(grid,2),1);
err_4_y = zeros(size(grid,2),1);
err_tot_y = zeros(size(grid,2),1);
i = 2;
for j = 1:size(grid,1)
    y_mid(j) = grid(i,j).location(2);
    y_top(j) = grid(i,j).location(2) + grid(i,j).edge_lengths(2)/2;
    r = [grid(i,j).location(1),grid(i,j).location(2)];
    R_y(j) = norm(r);
    err_3_y(j) = abs(grid(i,j).total_current(3)-grid_true(i,j).total_current(3))/grid_true(i,j).total_current(3);
    err_4_y(j) = abs(grid(i,j).total_current(4)-grid_true(i,j).total_current(4))/grid_true(i,j).total_current(4);
    err_tot_y(j) = abs(grid(i,j).avg_N_absorb-grid_true(i,j).avg_N_absorb)/grid_true(i,j).avg_N_absorb;
end

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(y_mid,err_3_y(:,1),'-x','color',colors{1})
xlabel('y')
ylabel('Relative Error')
title('Current Error - Face 3')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(y_mid,err_4_y(:,1),'-x','color',colors{1})
xlabel('y')
ylabel('Relative Error')
title('Current Error - Face 4')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(y_mid,err_tot_y(:),'-x','color',colors{1})
xlabel('y')
ylabel('Relative Error')
title('Absorption Error')
m = m + 1;


