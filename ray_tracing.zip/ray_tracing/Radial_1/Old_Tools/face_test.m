
%Get the optical depth and current distributions across face 4 for zone i,5 
%for columns 1-4
%Plot them against each other


zones = [1,5; 2,5; 3,5; 4,5; 5,5;, 6,5];
%colors = {'blue','red','magenta','green'};
colors = {'#0072BD','#D95319','#7E2F8E','#77AC30','#A2142F','#EDB120','#4DBEEE'}
names = {'i=1','i=2','i=3','i=4','i=5','i=6'};
pts = 200;
r_s = [0,0];
source_gp = [1,1];
q = 1e6;

x = zeros(size(grid(1,1).opt_depth_4,1), size(zones,1));
y = zeros(size(grid(1,1).opt_depth_4,1), size(zones,1));
sigma_bar_3 = zeros(size(grid(1,1).opt_depth_4,1), size(zones,1));
opt_depth_3 = zeros(size(grid(1,1).opt_depth_4,1), size(zones,1));
current_3 = zeros(size(grid(1,1).opt_depth_4,1), size(zones,1));
sigma_bar_4 = zeros(size(grid(1,1).opt_depth_4,1), size(zones,1));
opt_depth_4 = zeros(size(grid(1,1).opt_depth_4,1), size(zones,1));
current_4 = zeros(size(grid(1,1).opt_depth_4,1), size(zones,1));

for z = 1:size(zones,1)
    i = zones(z,1);
    j = zones(z,2);
    for k = 1:size(grid(1,1).opt_depth_4,1)
        x(k,z) = grid(i,j).opt_depth_4(k,1);
        y(k,z) = grid(i,j).opt_depth_3(k,2);
        opt_depth_3(k,z) = grid(i,j).opt_depth_3(k,3);
        sigma_bar_3(k,z) = grid(i,j).sigma_bar_3(k,3);
        current_3(k,z) = grid(i,j).currents_3(k,3);
        opt_depth_4(k,z) = grid(i,j).opt_depth_4(k,3);
        sigma_bar_4(k,z) = grid(i,j).sigma_bar_4(k,3);
        current_4(k,z) = grid(i,j).currents_4(k,3);
    end
end


x_hr = zeros(pts,size(zones,1));
y_hr = zeros(pts,size(zones,1));
sigma_bar_3_hr = zeros(pts,size(zones,1));
opt_depth_3_hr = zeros(pts,size(zones,1));
current_3_hr = zeros(pts,size(zones,1));
sigma_bar_4_hr = zeros(pts,size(zones,1));
opt_depth_4_hr = zeros(pts,size(zones,1));
current_4_hr = zeros(pts,size(zones,1));

for z = 1:size(zones,1)
    i = zones(z,1);
    j = zones(z,2);
    x1 = grid(i,j).location(1) - grid(i,j).edge_lengths(1)/2;
    x2 = grid(i,j).location(1) + grid(i,j).edge_lengths(1)/2;
    x_hr(:,z) = linspace(x1,x2,pts);
    y1 = grid(i,j).location(2) - grid(i,j).edge_lengths(2)/2;
    y2 = grid(i,j).location(2) + grid(i,j).edge_lengths(2)/2;
    y_hr(:,z) = linspace(y1,y2,pts);
    for k = 1:pts
        r = [x2,y_hr(k,z)];
        R = norm(r);
        sigma_bar_3_hr(k,z) = average_xs(r,r_s,source_gp,grid,i,j);
        opt_depth_3_hr(k,z) = sigma_bar_3_hr(k,z)*R;
        current_3_hr(k,z) = q*exp(-opt_depth_3_hr(k,z))/R * dot([1,0],(r-r_s)/R);
        r = [x_hr(k,z),y2];
        R = norm(r);
        sigma_bar_4_hr(k,z) = average_xs(r,r_s,source_gp,grid,i,j);
        opt_depth_4_hr(k,z) = sigma_bar_4_hr(k,z)*R;
        current_4_hr(k,z) = q*exp(-opt_depth_4_hr(k,z))/R * dot([0,1],(r-r_s)/R);
    end
end


figsize = [50 50 800 600];
fontsize = 15;
gridlines = 1;
m = 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(y_hr(:,1),sigma_bar_3_hr(:,1),'color',colors{1})
hold on 
for z = 2:size(zones,1)
    plot(y_hr(:,z),sigma_bar_3_hr(:,z),'color',colors{z})
end
for z = 1:size(zones,1)
    plot(y(:,z),sigma_bar_3(:,z),'x','color',colors{z})
end
hold off
legend(names)
xlabel('y')
ylabel('Sigma bar')
title('Average Cross Section - Face 3')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(y_hr(:,1),opt_depth_3_hr(:,1),'color',colors{1})
hold on 
for z = 2:size(zones,1)
    plot(y_hr(:,z),opt_depth_3_hr(:,z),'color',colors{z})
end
for z = 1:size(zones,1)
    plot(y(:,z),opt_depth_3(:,z),'x','color',colors{z})
end
hold off
legend(names)
xlabel('y')
ylabel('Optical Depth')
title('Optical Depth - Face 3')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(y_hr(:,1),current_3_hr(:,1),'color',colors{1})
hold on 
for z = 2:size(zones,1)
    plot(y_hr(:,z),current_3_hr(:,z),'color',colors{z})
end
for z = 1:size(zones,1)
    plot(y(:,z),current_3(:,z),'x','color',colors{z})
end
hold off
legend(names)
xlabel('y')
ylabel('Current')
title('Current - Face 3')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(x_hr(:,1),sigma_bar_4_hr(:,1),'color',colors{1})
hold on 
for z = 2:size(zones,1)
    plot(x_hr(:,z),sigma_bar_4_hr(:,z),'color',colors{z})
end
for z = 1:size(zones,1)
    plot(x(:,z),sigma_bar_4(:,z),'x','color',colors{z})
end
hold off
legend(names)
xlabel('x')
ylabel('Sigma bar')
title('Average Cross Section')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(x_hr(:,1),opt_depth_4_hr(:,1),'color',colors{1})
hold on 
for z = 2:size(zones,1)
    plot(x_hr(:,z),opt_depth_4_hr(:,z),'color',colors{z})
end
for z = 1:size(zones,1)
    plot(x(:,z),opt_depth_4(:,z),'x','color',colors{z})
end
hold off
legend(names)
xlabel('x')
ylabel('Optical Depth')
title('Optical Depth')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
plot(x_hr(:,1),current_4_hr(:,1),'color',colors{1})
hold on 
for z = 2:size(zones,1)
    plot(x_hr(:,z),current_4_hr(:,z),'color',colors{z})
end
for z = 1:size(zones,1)
    plot(x(:,z),current_4(:,z),'x','color',colors{z})
end
hold off
legend(names)
xlabel('x')
ylabel('Current')
title('Current')
m = m + 1;



y_mid = zeros(size(grid,2),1);
y_top = zeros(size(grid,2),1);
R = zeros(size(grid,2),1);
err_3 = zeros(size(grid,2),size(zones,1));
err_4 = zeros(size(grid,2),size(zones,1));
err_tot = zeros(size(grid,2),size(zones,1));
for z = 1:size(zones,1)
    i = zones(z,1);
    for j = 1:size(grid,2)
        if z == 1
            y_mid(j) = grid(i,j).location(2);
            y_top(j) = grid(i,j).location(2) + grid(i,j).edge_lengths(2)/2;
        end
        r = [grid(i,j).location(1),grid(i,j).location(2)];
        R(j,z) = norm(r);
        err_3(j,z) = abs(grid(i,j).total_current(3)-grid_true(i,j).total_current(3))/grid_true(i,j).total_current(3);
        err_4(j,z) = abs(grid(i,j).total_current(4)-grid_true(i,j).total_current(4))/grid_true(i,j).total_current(4);
        err_tot(j,z) = abs(grid(i,j).avg_N_absorb-grid_true(i,j).avg_N_absorb)/grid_true(i,j).avg_N_absorb;
    end
end

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(R(:,1),err_3(:,1),'-x','color',colors{1})
hold on 
for z = 2:size(zones,1)
    semilogy(R(:,z),err_3(:,z),'-x','color',colors{z})
end
hold off
legend(names)
xlabel('R')
ylabel('Relative Error')
title('Current Error - Face 3')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(R(:,1),err_4(:,1),'-x','color',colors{1})
hold on 
for z = 2:size(zones,1)
    semilogy(R(:,z),err_4(:,z),'-x','color',colors{z})
end
hold off
legend(names)
xlabel('R')
ylabel('Relative Error')
title('Current Error - Face 4')
m = m + 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(R(:,1),err_tot(:,1),'-x','color',colors{1})
hold on 
for z = 2:size(zones,1)
    semilogy(R(:,z),err_tot(:,z),'-x','color',colors{z})
end
hold off
legend(names)
xlabel('R')
ylabel('Relative Error')
title('Absorption Error')
m = m + 1;

