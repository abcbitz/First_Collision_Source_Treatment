
%Use to find compatible meshes to test watch points

%pattern is every twice whatever the total zones is

L = 1;
p = [0.25,0.75];    %2 6 10 14 18 22 26 30 34 38
p = [0.55,0.35];    %10 30
p = [0.65,0.85];    %10 30
p = [0.1,0.3];      %15 25 35

dx = 1/2;
p = [2,5]*dx - dx/2;    %2 6 10 14 18 22 26 30 34 38


dx = 1/6;
p = [1,3]*dx - dx/2;    %6 18 30 42 54 
p = [2,1]*dx - dx/2;    %6 18 30 42 54 
p = [2,5]*dx - dx/2;    %2 6 10 14 18 22 26 30 34 38
p = [4,3]*dx - dx/2;    %6 18 30 42 54 
p = [4,5]*dx - dx/2;    %6 18 30 42 54 

%p = [0.12500,0.12500; 0.12500,0.37500; 0.12500,0.62500; 0.12500,0.87500; ...
%    0.37500,0.37500; 0.37500,0.62500; 0.37500,0.87500; 0.87500,0.87500;];

% dx = 1/3;
% p = [1,1]*dx - dx/2;
% p = [1,2]*dx - dx/2;
% %p = [1,3]*dx - dx/2;    %3 9 15 21 27 33 39 45 51 57 
% 
% 
% dx = 1/4;
% p = [2,3]*dx - dx/2;
% p = [2,4]*dx - dx/2;    %4 12 20 28 36
% p = [4,4]*dx - dx/2;    %4 12 20 28 36

%dx = 1/5;
%p = [2,3]*dx - dx/2;
%p = [2,4]*dx - dx/2;   
%p = [4,4]*dx - dx/2;    %5 15 25 35 45 55 

%dx = 1/8;
%p = [1,2]*dx - dx/2;    %8 24 40 56
%p = [3,3]*dx - dx/2;    %8 24 40 56



fprintf('p = [%.5f,%.5f]\n',p(1),p(2))
for m = 1:60    %num zones
    dx = L/m;
    dy = L/m;
    flag_x = 0;
    flag_y = 0;
    if m == 6
        disp('')
    end
    for n = 1:m     %current zone
        if abs(p(1) - (n*dx - dx/2)) <= 1e-10
            flag_x = 1;
        end
        if abs(p(2) - (n*dy - dy/2)) <= 1e-10
            flag_y = 1;
        end
        if flag_x == 1 && flag_y == 1
            fprintf('%i ',m);
            break
        end
    end
end 

fprintf('\n')

dx = 1/6;
fprintf('wp = [');
x = dx/2;
y = dx/2;
for i = 1:1/dx
    x = dx/2;
    for j = 1:1/dx
        fprintf('%.4f,%.4f;',x,y);
        x = x + dx;
    end
    y = y + dx;
end
fprintf('];\n')

