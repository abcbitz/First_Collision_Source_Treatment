
%Looks at how the current converges along a face as you increase rays

%load in grid true

addpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
addpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
addpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))

N_zones = 20;
N_max = 20;
face = 4;
r_s = [0.0,0.0];

%m is starting figure number
[i,j,m] = deal(1,14,17);
%[i,j,m] = deal(3,12,4);

source_gp = source_zone(r_s,grid);
true_current = grid_true(i,j).total_current(face);

dx = 1/N_zones;
dy = 1/N_zones;

avg_currents = zeros(N_max,1);
for N = 1:N_max
    currents = zeros(N,1);
    [r,w] = quad_points_surf(grid,i,j,face,N,'Gauss');
    for n = 1:N
        R = sqrt(sum((r(n,:) - r_s).^2));
        sigma_bar = average_xs(r(n,:),r_s,source_gp,grid,i,j);
        opt_depth = sigma_bar*R;
        if face == 1 
            currents(n) = q*exp(-opt_depth)/R * dot([-1,0],(r(n,:)-r_s)/R);
        elseif face == 2
            currents(n) = q*exp(-opt_depth)/R * dot([0,-1],(r(n,:)-r_s)/R);
        elseif face == 3
            currents(n) = q*exp(-opt_depth)/R * dot([1,0],(r(n,:)-r_s)/R);
        elseif face == 4
            currents(n) = q*exp(-opt_depth)/R * dot([0,1],(r(n,:)-r_s)/R);
        end
    end
    
    avg_currents(N) = sum(w.*currents)/dx; %Gauss quadrature
end

rel_diff = abs(avg_currents(2:end)-avg_currents(1:end-1))./avg_currents(2:end);
rel_diff = rel_diff + 1e-16;


figsize = [50 50 800 600];
fontsize = 15;
gridlines = 1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1:N_max,avg_currents,'-x')
xlabel('N')
ylabel('Average Current')
title(sprintf('Current_%i - Zone (%i,%i) - Gauss',face,i,j))
m = m+1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize,'renderer','painter')
semilogy(2:N_max,rel_diff,'-x')
xlabel('N')
%ylabel('Relative Difference')
ylabel('$\frac{|J_{N}-J_{N-1}|}{J_{N}}$','interpreter','latex','fontsize',20)
title(sprintf('Current_%i Convergence - Zone (%i,%i) - Gauss',face,i,j))
m = m+1;

figure(m)
clf(m)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize,'renderer','painter')
semilogy(1:N_max,abs(avg_currents-true_current)/true_current,'-x')
xlabel('N')
ylabel('Relative Error')
title(sprintf('Relative Error - Face %i - Zone (%i,%i) - Gauss',face,i,j))
m = m+1;




%trapz stuff wont work right now
%%%%%%%%%%%%%%%%%%%%%%%%%%%% Trapz %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% dx = 1/21;
% dy = 1/21;
% x = linspace(grid(i,j).location(1)-dx/2, grid(i,j).location(1)+dx/2, 100);
% y = linspace(grid(i,j).location(2)-dy/2, grid(i,j).location(2)+dy/2, 100);
% 
% avg_currents_tr = zeros(N_max,1);
% for N = 2:N_max
%     currents_4_tr = zeros(N,1);
%     [r,w] = quad_points_surf(grid,i,j,4,N,'Trapz');
%     for n = 1:N
%         R = sqrt(sum((r(n,:) - r_s).^2));
%         sigma_bar = average_xs(r(n,:),r_s,source_gp,grid,i,j);
%         opt_depth = sigma_bar*R;
%         currents_4_tr(n) = q*exp(-opt_depth)/R * dot([0,1],(r(n,:)-r_s)/R);
%     end
%     
%     avg_currents_tr(N) = trapz(r(:,1),currents_4_tr)/dx;
% end
% 
% rel_diff_tr = abs(avg_currents_tr(2:end)-avg_currents_tr(1:end-1))./avg_currents_tr(2:end);
% rel_diff_tr = rel_diff_tr + 1e-16;
% 
% figure(m)
% clf(m)
% set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
% semilogy(1:N_max,avg_currents_tr,'-x')
% xlabel('N')
% ylabel('Average Current')
% title(sprintf('Current - Trapz - Zone (%i,%i)',i,j))
% m = m+1;
% 
% figure(m)
% clf(m)
% set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
% semilogy(2:N_max,rel_diff_tr,'-x')
% xlabel('N')
% ylabel('$\frac{|J_{N}-J_{N-1}|}{J_{N}}$','interpreter','latex','fontsize',20)
% title(sprintf('Current Convergence - Trapz - Zone (%i,%i)',i,j))
% m = m+1;
% 
% figure(m)
% clf(m)
% set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize,'renderer','painter')
% semilogy(1:N_max,abs(avg_currents_tr-true_current)/true_current,'-x')
% xlabel('N')
% ylabel('Relative Difference')
% %ylabel('$\frac{|J_{N}-J_{N-1}|}{J_{N}}$','interpreter','latex','fontsize',20)
% title(sprintf('Relative Error - Trapz - Zone (%i,%i)',i,j))
% m = m+1;
% 
% figure(m)
% clf(m)
% set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize,'renderer','painter')
% semilogy(1:N_max,abs(currents-currents_4_tr)./currents,'-x')
% xlabel('N')
% ylabel('Relative Difference')
% title(sprintf('Relative Difference - Zone (%i,%i)',i,j))
% m = m+1;
% 
% figure(m)
% clf(m)
% set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize,'renderer','painter')
% semilogy(1:N_max,currents,'-x')
% hold on
% semilogy(1:N_max,currents,'-x')
% hold off
% xlabel('N')
% ylabel('Current')
% title(sprintf('Current at N_max - Zone (%i,%i)',i,j))
% m = m+1;


rmpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
rmpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
rmpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))




