%Looks at the convergence of the solution as the mesh size changes
% - subdivides the face while keeping the actual mesh constant
clear

addpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
addpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
addpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))

N_zones = 30;
N_rays_per_div = 2;
max_divs = 5;
wp = 6;
wp_list = [1,1; 1,5; 2,5; 5,2];

q = 1e6;
L = 1;
H = 1;
r_s = [0.0,0.0];


dim = [L,H];

x = linspace(0,L,N_zones+1);
y = linspace(0,H,N_zones+1);
%[X,Y] = meshgrid(x,y);
[Y,X] = meshgrid(x,y);
x = (x(1:end-1)+x(2:end))/2;
y = (y(1:end-1)+y(2:end))/2;

flux = zeros(N_zones+1,N_zones+1,max_divs);
N_abs = zeros(N_zones+1,N_zones+1,max_divs);
current_3 = zeros(N_zones+1,N_zones+1,max_divs);
current_4 = zeros(N_zones+1,N_zones+1,max_divs);
for N = 1:max_divs
    grid = surf_subdiv([N_zones,N_zones],dim,q,r_s,1e-15,1e-15,N,N_rays_per_div);
    for i = 1:N_zones
        for j = 1:N_zones
            flux(i,j,N) = grid(i,j).avg_flux;
            N_abs(i,j,N) = grid(i,j).avg_N_absorb;
            current_3(i,j,N) = grid(i,j).total_current(3);
            current_4(i,j,N) = grid(i,j).total_current(4);
        end
    end
end


grid_true = true_solution([N_zones,N_zones],dim,q,r_s,1e-15,1e-15,20,3);
flux_true = zeros(N_zones+1);
N_abs_true = zeros(N_zones+1);
current_3_true = zeros(N_zones+1);
current_4_true = zeros(N_zones+1);
xs = zeros(N_zones+1);
for i = 1:N_zones
    for j = 1:N_zones
        flux_true(i,j) = grid_true(i,j).avg_flux;
        N_abs_true(i,j) = grid_true(i,j).avg_N_absorb;
        current_3_true(i,j) = grid_true(i,j).total_current(3);
        current_4_true(i,j) = grid_true(i,j).total_current(4);
        xs(i,j) = grid_true(i,j).sigma_a;
    end
end


dx = dim(1)/wp;
x_wp = zeros(wp,1);
for i = 1:wp
    x_wp(i) = (i-0.5)*dx;
end
dy = dim(2)/wp;
y_wp = zeros(wp,1);
for i = 1:wp
    y_wp(i) = (i-0.5)*dy;
end
N_abs_wp = zeros(wp);
N_abs_true_wp = zeros(wp);
rel_abs_error_wp = zeros(wp);
current_3_wp = zeros(wp);
current_3_true_wp = zeros(wp);
rel_cur_3_error_wp = zeros(wp);
current_4_wp = zeros(wp);
current_4_true_wp = zeros(wp);
rel_cur_4_error_wp = zeros(wp);


for p = 1:wp
    for k = 1:wp
        for i = 1:N_zones
            for j = 1:N_zones
                for N = 1:max_divs
                    if abs(x(i)-x_wp(p)) <= 1e-10 && abs(y(j)-y_wp(k)) <= 1e-10
                        N_abs_wp(p,k,N) = N_abs(i,j,N);
                        N_abs_true_wp(p,k) = N_abs_true(i,j);
                        rel_abs_error_wp(p,k,N) = abs(N_abs(i,j,N)-N_abs_true(i,j))/N_abs_true(i,j);
                        current_3_wp(p,k,N) = current_3(i,j,N);
                        current_3_true_wp(p,k) = current_3_true(i,j);
                        rel_cur_3_error_wp(p,k,N) = abs((current_3_true(i,j)-current_3(i,j,N))/current_3_true(i,j));
                        current_4_wp(p,k,N) = current_4(i,j,N);
                        current_4_true_wp(p,k) = current_4_true(i,j);
                        rel_cur_4_error_wp(p,k,N) = abs((current_4_true(i,j)-current_4(i,j,N))/current_4_true(i,j));
                    end
                end
            end
        end
    end
end
wp_L1 = sum(sum(abs(N_abs_wp-N_abs_true_wp)))/sum(sum(N_abs_true_wp));
    
    
%%%%%%%%%%%%%%%%%%%%%
figsize = [50 50 800 600];
fontsize = 15;
gridlines = 1;
n = 1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X,Y,xs);
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title('Cross Section',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X,Y,flux(:,:,end));
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title(sprintf('Flux - Num Zones = %i',N_zones),' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')
set(gca,'ColorScale','log')
mm = [10^floor(log10(min(min(flux(1:end-1,1:end-1,end))))),10^ceil(log10(max(max(flux(1:end-1,1:end-1,end)))))];
if min(min(flux(:,:,end))) > 0.0
    caxis(mm);
end
n = n+1;


for i = 1:max_divs
    figure(n)
    clf(n)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    s = pcolor(X,Y,abs(flux(:,:,i)-flux_true)./flux_true);
    if gridlines ~= 1
        s.EdgeColor = 'none';
    end
    title(sprintf('Relative Flux Error - Num Divs = %i',i),' ','Fontsize',18)
    xlabel('x [cm]')
    ylabel('y [cm]')
    colormap turbo
    colorbar('Location','westoutside')
    set(gca,'ColorScale','log')
    mm = [1e-15,1e-1];
    caxis(mm);
    n = n+1;
end

for i = 1:max_divs
    figure(n)
    clf(n)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    s = pcolor(X,Y,abs(current_3(:,:,i)-current_3_true)./current_3_true);
    if gridlines ~= 1
        s.EdgeColor = 'none';
    end
    title(sprintf('Relative Current 3 Error - Num Divs = %i',i),' ','Fontsize',18)
    xlabel('x [cm]')
    ylabel('y [cm]')
    colormap turbo
    colorbar('Location','westoutside')
    set(gca,'ColorScale','log')
    mm = [1e-15,1e-1];
    caxis(mm);
    n = n+1;
end

for i = 1:max_divs
    figure(n)
    clf(n)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    s = pcolor(X,Y,abs(current_4(:,:,i)-current_4_true)./current_4_true);
    if gridlines ~= 1
        s.EdgeColor = 'none';
    end
    title(sprintf('Relative Current 4 Error - Num Divs = %i',i),' ','Fontsize',18)
    xlabel('x [cm]')
    ylabel('y [cm]')
    colormap turbo
    colorbar('Location','westoutside')
    set(gca,'ColorScale','log')
    mm = [1e-15,1e-1];
    caxis(mm);
    n = n+1;
end

dx = grid_true(1,1).edge_lengths(1)./(1:max_divs);
[Y_wp,X_wp] = meshgrid(linspace(0,1,wp+1),linspace(0,1,wp+1));
m_abs = zeros(wp+1);
m_3 = zeros(wp+1);
m_4 = zeros(wp+1);
for i = 1:wp
    for j = 1:wp
        %m_abs(i,j) = (log10(rel_abs_error_wp(i,j,3))-log10(rel_abs_error_wp(i,j,1)))/(log10(dx(3))-log10(dx(1)));
        %m_3(i,j) = (log10(rel_cur_3_error_wp(i,j,3))-log10(rel_cur_3_error_wp(i,j,1)))/(log10(dx(3))-log10(dx(1)));
        %m_4(i,j) = (log10(rel_cur_4_error_wp(i,j,3))-log10(rel_cur_4_error_wp(i,j,1)))/(log10(dx(3))-log10(dx(1)));
        m_abs(i,j) = (log10(rel_abs_error_wp(i,j,2))-log10(rel_abs_error_wp(i,j,1)))/(log10(dx(2))-log10(dx(1)));
        m_3(i,j) = (log10(rel_cur_3_error_wp(i,j,2))-log10(rel_cur_3_error_wp(i,j,1)))/(log10(dx(2))-log10(dx(1)));
        m_4(i,j) = (log10(rel_cur_4_error_wp(i,j,2))-log10(rel_cur_4_error_wp(i,j,1)))/(log10(dx(2))-log10(dx(1)));
        
        if wp_list(1) == -1 || sum(wp_list(:,1) == i & wp_list(:,2) == j) == 1
            figure(n)
            clf(n)
            set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
            loglog(dx,reshape(rel_abs_error_wp(i,j,:),max_divs,1,1),'x-')
            hold on
            loglog(dx,reshape(rel_cur_3_error_wp(i,j,:),max_divs,1,1),'x-')
            loglog(dx,reshape(rel_cur_4_error_wp(i,j,:),max_divs,1,1),'x-')
            hold off
            xlabel('dx [cm]')
            ylabel('Relative Error')
            legend('Absorbtion','Current 3','Current 4','Location','southoutside','NumColumns',3)
            title(sprintf('Relative Error - wp(%i,%i) = [%.3f,%.3f]',i,j,x_wp(i),y_wp(j)))
            n = n + 1;
        end
        
        fprintf('wp(%i,%i) = [%.3f,%.3f]\n',i,j,x_wp(i),y_wp(j))
        fprintf('[m_abs, m_cur3, m_cur4] = [%.4f, %.4f, %.4f]\n',m_abs(i,j),m_3(i,j),m_4(i,j))
    end
end

for i = 1:wp
    m_abs(i,wp+1) = m_abs(i,wp);
    m_3(i,wp+1) = m_3(i,wp);
    m_4(i,wp+1) = m_4(i,wp);
end 
for j = 1:wp
    m_abs(wp+1,j) = m_abs(wp,j);
    m_3(wp+1,j) = m_3(wp,j);
    m_4(wp+1,j) = m_4(wp,j);
end
m_abs(wp+1,wp+1) = m_abs(wp+1,wp);
m_3(wp+1,wp+1) = m_3(wp+1,wp);
m_4(wp+1,wp+1) = m_4(wp+1,wp);

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X_wp,Y_wp,m_abs);
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title('Absorp Error Slope',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')
%caxis([5,7])
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X_wp,Y_wp,m_3);
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title('Current 3 Slope',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')
%caxis([5,7])
n = n+1;

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
s = pcolor(X_wp,Y_wp,m_4);
if gridlines ~= 1
    s.EdgeColor = 'none';
end
title('Current 4 Slope',' ','Fontsize',18)
xlabel('x [cm]')
ylabel('y [cm]')
colormap turbo
colorbar('Location','westoutside')
%caxis([5,7])
n = n+1;


rmpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
rmpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
rmpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))







