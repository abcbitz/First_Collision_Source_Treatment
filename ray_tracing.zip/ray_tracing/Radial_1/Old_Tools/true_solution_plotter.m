%Looks at the convergence of the true solution as the mesh size changes

%TO RUN
%Add path to surface functions
%If function, may want to consider using integral

%4x4 - 4 12 20 28 36 44 52 60
% num_zones = [4,12,20,28,36,44,52];
% wp = [0.1250,0.1250;0.3750,0.1250;0.6250,0.1250;0.8750,0.1250;0.1250,0.3750;...
%     0.3750,0.3750;0.6250,0.3750;0.8750,0.3750;0.1250,0.6250;0.3750,0.6250;...
%     0.6250,0.6250;0.8750,0.6250;0.1250,0.8750;0.3750,0.8750;0.6250,0.8750;...
%     0.8750,0.8750];

%6x6 - 6 18 30 42 54 66
num_zones = [6,18,30,42,54,66,78,90];
wp = [0.0833,0.0833;0.2500,0.0833;0.4167,0.0833;0.5833,0.0833;0.7500,0.0833;...
    0.9167,0.0833;0.0833,0.2500;0.2500,0.2500;0.4167,0.2500;0.5833,0.2500;...
    0.7500,0.2500;0.9167,0.2500;0.0833,0.4167;0.2500,0.4167;0.4167,0.4167;...
    0.5833,0.4167;0.7500,0.4167;0.9167,0.4167;0.0833,0.5833;0.2500,0.5833;...
    0.4167,0.5833;0.5833,0.5833;0.7500,0.5833;0.9167,0.5833;0.0833,0.7500;...
    0.2500,0.7500;0.4167,0.7500;0.5833,0.7500;0.7500,0.7500;0.9167,0.7500;...
    0.0833,0.9167;0.2500,0.9167;0.4167,0.9167;0.5833,0.9167;0.7500,0.9167;...
    0.9167,0.9167;];

x_wp = unique(wp(:,1),'sorted');
y_wp = unique(wp(:,2),'sorted');
[X,Y] = meshgrid(x_wp,y_wp);
X = X - (x_wp(2)-x_wp(1))/2;
Y = Y - (y_wp(2)-y_wp(1))/2;

for i = 1:length(x_wp)
    X(i,length(y_wp)+1) = x_wp(end) + (x_wp(end)-x_wp(end-1))/2;
    Y(i,length(y_wp)+1) = Y(i,length(y_wp));
end
for j = 1:length(y_wp)
    X(length(x_wp)+1,j) = X(length(x_wp),j);
    Y(length(x_wp)+1,j) = y_wp(end) + (y_wp(end)-y_wp(end-1))/2;
end
X(length(x_wp)+1,length(y_wp)+1) = X(length(x_wp),length(y_wp)+1);
Y(length(x_wp)+1,length(y_wp)+1) = Y(length(x_wp)+1,length(y_wp));

figsize = [50 50 800 600];
fontsize = 15;
gridlines = 1;
n = 1;

wp_xs = zeros(size(wp,1),length(num_zones));
wp_flux = zeros(size(wp,1),length(num_zones));
wp_flux_grid = ones(length(x_wp)+1, length(y_wp)+1, length(num_zones))*1e-12;   %size+1 for plotting
wp_rel_error_1 = zeros(length(num_zones)-1, length(x_wp)+1, length(y_wp)+1);
wp_rel_error_2 = zeros(length(num_zones)-1, length(x_wp)+1, length(y_wp)+1);
L1_wp_error_1 = zeros(length(num_zones)-1, 1);
L1_wp_error_2= zeros(length(num_zones)-1, 1);
for N = 1:length(num_zones)
    N_zones = num_zones(N);
    x = zeros(N_zones);
    y = zeros(N_zones);
    flux = zeros(N_zones);
    N_abs = zeros(N_zones);
    xs = zeros(N_zones);
    grid1 = build_grid([N_zones,N_zones],[1,1]);
    grid_true = true_solution(grid1,1e6,[0,0],1e-14,1e-9,20);
    %load(sprintf('true_soln__%i_zones.mat',N_zones));
    for i = 1:N_zones
        for j = 1:N_zones
            x(i,j) = grid_true(i,j).location(1);
            y(i,j) = grid_true(i,j).location(2);
            flux(i,j) = grid_true(i,j).avg_flux;
            N_abs(i,j) = grid_true(i,j).avg_N_absorb;
            xs(i,j) = grid_true(i,j).sigma_a;
            
            for p = 1:size(wp,1)
                if abs(x(i,j)-wp(p,1)) <= 1e-3 && abs(y(i,j)-wp(p,2)) <= 1e-3
                    wp_flux(p,N) = flux(i,j);
                    wp_xs(p,N) = xs(i,j);
                    break
                end
            end
        end
    end
    
    p = 1;  %wp counter
    for i = 1:length(x_wp)
        for j = 1:length(y_wp)
            wp_flux_grid(i,j,N) = wp_flux(p,N);  %Remap wp_abs to grid
            p = p + 1;
        end
    end
    
    if N ~= 1        
        wp_rel_error_1(N-1,:,:) = abs(wp_flux_grid(:,:,N)-wp_flux_grid(:,:,N-1))./wp_flux_grid(:,:,N);
        L1_wp_error_1(N-1) = trapz(y_wp,trapz(x_wp,abs(wp_flux_grid(1:end-1,1:end-1,N)-wp_flux_grid(1:end-1,1:end-1,N-1))./wp_flux_grid(1:end-1,1:end-1,N),2));
    end
    
    figure(n)
    clf(n)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    s = pcolor(X,Y,wp_flux_grid(:,:,N));
    if gridlines ~= 1
        s.EdgeColor = 'none';
    end
    title(sprintf('Flux - Num Zones = %i',N_zones),' ','Fontsize',18)
    xlabel('x [cm]')
    ylabel('y [cm]')
    colormap turbo
    colorbar('Location','westoutside')
    set(gca,'ColorScale','log')
    %mm = [10^floor(log10(min(min(wp_abs_grid(:,:,N))))),10^ceil(log10(max(max(wp_abs_grid(:,:,N)))))];
    mm = [10^floor(log10(min(min(wp_flux_grid(1:end-1,1:end-1,N))))),10^ceil(log10(max(max(wp_flux_grid(1:end-1,1:end-1,N)))))];
    if min(min(wp_flux_grid(:,:,N))) > 0.0
        caxis(mm);
    end
    %extra_axes(num_zones,2)
    %save_plot(figure(n),sprintf('%s\\N_abs',folder),savePlots)
    n = n+1;
end


for N = 1:length(num_zones)-1
    wp_rel_error_2(N,:,:) = abs(wp_flux_grid(:,:,end)-wp_flux_grid(:,:,N))./wp_flux_grid(:,:,end);
    L1_wp_error_2(N) = trapz(y_wp,trapz(x_wp,abs(wp_flux_grid(1:end-1,1:end-1,N)-wp_flux_grid(1:end-1,1:end-1,end))./wp_flux_grid(1:end-1,1:end-1,end),2));
    
    figure(n)
    clf(n)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    s = pcolor(X,Y,abs(wp_flux_grid(:,:,end)-wp_flux_grid(:,:,N))./wp_flux_grid(:,:,end));
    if gridlines ~= 1
        s.EdgeColor = 'none';
    end
    title(sprintf('Flux Error - Num Zones = %i',num_zones(N)),' ','Fontsize',18)
    xlabel('x [cm]')
    ylabel('y [cm]')
    colormap turbo
    colorbar('Location','westoutside')
    set(gca,'ColorScale','log')
    mm = [10^floor(log10(min(min(wp_rel_error(N,1:end-1,1:end-1))))),10^ceil(log10(max(max(wp_rel_error(N,1:end-1,1:end-1)))))];
    if min(min(wp_rel_error(N,1:end-1,1:end-1))) > 0.0
        caxis(mm);
    end
    %extra_axes(num_zones,2)
    %save_plot(figure(n),sprintf('%s\\N_abs',folder),savePlots)
    n = n+1;
end

dx = 1./num_zones;
x_bounds = [10^floor(log10(min(dx))),10^ceil(log10(max(dx)))];

figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(dx(1:end-1),L1_wp_error_2,'x-')
if gridlines == 1
    grid on
end
title('L1 Flux Error',' ','Fontsize',18)
xlabel('dx [cm]')
ylabel('L1 Relative Error')
%xlim([0.01,0.4])
%xticks([1e-2,1e-1])
%xlim([0.01,1])
xlim(x_bounds)
n = n + 1;

%plot L1
figure(n)
clf(n)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(dx(2:end),L1_wp_error_1,'x-')
if gridlines == 1
    grid on
end
title('L1 Flux Error',' ','Fontsize',18)
xlabel('dx [cm]')
ylabel('$\sum_{n=1}^{N}\frac{|\Phi_{N}-\Phi_{N-1}|}{\Phi_{N}}$','interpreter','latex','fontsize',20)
%xlim([0.01,0.4])
%xticks([1e-2,1e-1])
%xlim([0.01,1])
xlim(x_bounds)
%extra_axes(num_zones,1)
%save_plot(figure(n),sprintf('%s\\sigma_bar_j1',folder),savePlots)
n = n+1;

%plot local convergence
for i = 1:length(x_wp)
    for j = 1:length(y_wp)
        figure(n)
        clf(n)
        set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
        loglog(dx(1:end-1),wp_rel_error_2(:,i,j),'x-')
        if gridlines == 1
            grid on
        end
        title(sprintf('Relative Flux Error at (x,y) = (%.3f,%.3f)',x_wp(i),y_wp(j)),' ','Fontsize',18)
        xlabel('dx [cm]')
        ylabel('Relative Error')
        %xlim([0.01,0.4])
        %xticks([1e-2,1e-1])
        %xlim([0.01,1])
        xlim(x_bounds)
        %ylim([1e-6,1])
        ylim([1e-6,1e0])
        n = n + 1;
    end
end

% for i = 1:length(x_wp)
%     for j = 1:length(y_wp)
%         figure(n)
%         clf(n)
%         set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
%         loglog(dx(2:end),wp_rel_error_1(:,i,j),'x-')
%         if gridlines == 1
%             grid on
%         end
%         title(sprintf('Flux Convergence at (x,y) = (%.3f,%.3f)',x_wp(i),y_wp(j)),' ','Fontsize',18)
%         xlabel('dx [cm]')
%         ylabel('L1 Relative Error')
%         ylabel('$\frac{|\Phi_{N}-\Phi_{N-1}|}{\Phi_{N}}$','interpreter','latex','fontsize',20)
%         n = n + 1;
%     end
% end


    
    
