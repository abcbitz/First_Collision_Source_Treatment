%Looks at the convergence of the current across the top face of quadrant
%1,1

q = 1e6;
a = 0.0;
b = 0.5;
y = b;
xs = 2;

J = @(x) q*y./(x.^2+y^2).*exp(-xs*sqrt(x.^2+y^2));
J_bar = 1/(b-a)*integral(J,a,b);

M_max = 20;
N = 4;


addpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
addpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
addpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))

currents = zeros(N,1);  %current at a qp
sigma = zeros(N,1);     %sigma_bar at qp
total_current = zeros(M_max,1); %total current through the face 4 in bottom left quadrant

%M is num zones
for M = 1:M_max
    grid = build_grid(2*[M,M],[1,1]);
    avg_zonal_currents = zeros(M,1);    %avg current through face 4 in zone
    dx = 0.5/M;
    for m = 1:M
        [r,w] = quad_points_surf(grid,m,M,4,N,'Gauss');
        for n = 1:N
            R = sqrt(sum(r(n,:).^2));
            sigma(n) = average_xs(r(n,:),[0.0,0.0],[1,1],grid,m,M);
            currents(n) = q*exp(-sigma(n)*R)/R * dot([0,1],r(n,:)/R);  
        end
        
        avg_zonal_currents(m) = sum(w.*currents)/dx;
    end
    
    total_current(M) = sum(avg_zonal_currents*dx)/0.5;
end

conv = abs(total_current(2:end)-total_current(1:end-1))./total_current(2:end) + 1e-16;
rel_diff = abs(J_bar-total_current)/J_bar + 1e-16;

f = 1;
figsize = [50 50 800 600];
fontsize = 15;
gridlines = 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
%semilogy((2:M_max).^2,conv,'-x')
semilogy(1./(2:M_max),conv,'-x')
xlabel('dx')
ylabel('$\frac{|J_{M}-J_{M-1}|}{J_{M}}$','interpreter','latex','fontsize',20)
title('Current Convergence')
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
%semilogy((1:M_max).^2,rel_diff,'-x')
semilogy(1./(1:M_max), rel_diff, '-x')
xlabel('dx')
ylabel('Relative Error','interpreter','latex','fontsize',20)
title('Relative Error')
f = f + 1;


rmpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
rmpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
rmpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))
