
%Looks at how the true solution converges for a specified zone as you
%increase the number of allowed sub divisions

%[i,j] = deal(3,12);
[i,j] = deal(2,16);
%[i,j] = deal(13,20);
source_gp = [1,1];
r_s = [0.0,0.0];
%max_er = 1e-14;
max_er = 1e-10;
max_divs = 16;
f = 10;

f_int = f;

for k = [3,5,7,9,11,13,15]
    if k == 3
        nodes = [-0.7745966692414833770359,0.0,0.7745966692414833770359];
        weights = [0.5555555555555555555556,0.8888888888888888888889,0.5555555555555555555556];
        max_divs = 14;
        
    elseif k == 5
        nodes = [-0.9258200997725514615666,-0.5773502691896257645092,0.0,...
            0.5773502691896257645092,0.9258200997725514615666];
        weights = [0.197979797979797979798,0.4909090909090909090909,0.6222222222222222222222,...
            0.4909090909090909090909,0.197979797979797979798];
        max_divs = 14;
        
    elseif k == 7
        nodes = [-0.9604912687080202834235,-0.7745966692414833770359,-0.4342437493468025580021,...
            0.0,0.4342437493468025580021,0.7745966692414833770359,0.9604912687080202834235];
        weights = [0.1046562260264672651938,0.2684880898683334407286,...
            0.4013974147759622229051,0.4509165386584741423451,0.4013974147759622229051,...
            0.2684880898683334407286,0.1046562260264672651938];
        max_divs = 12;
        
    elseif k == 9
        nodes = [-0.9765602507375731115345,-0.861136311594052575224,-0.6402862174963099824047,...
            -0.3399810435848562648027,0,0.3399810435848562648027,0.6402862174963099824047,...
            0.861136311594052575224,0.9765602507375731115345];
        weights = [0.06297737366547301476549,0.1700536053357227268027,0.2667983404522844480328,...
            0.326949189601451629558,0.346442981890136361681,0.326949189601451629558,0.2667983404522844480328,...
            0.1700536053357227268027,0.06297737366547301476549];
        max_divs = 12;
        
    elseif k == 11
        nodes = [-0.9840853600948424644962,-0.9061798459386639927976,-0.7541667265708492204408,...
            -0.5384693101056830910363,-0.2796304131617831934135,0,0.2796304131617831934135,...
            0.5384693101056830910363,0.7541667265708492204408,0.9061798459386639927976,...
            0.9840853600948424644962];
        weights = [0.04258203675108183286451,0.1152333166224733940246,0.186800796556492657468,...
            0.2410403392286475866999,0.272849801912558922341,0.2829874178574912132043,...
            0.272849801912558922341,0.2410403392286475866999,0.186800796556492657468,...
            0.1152333166224733940246,0.04258203675108183286451];
        max_divs = 12;
        
    elseif k == 13
        nodes = [-0.9887032026126788575047,-0.9324695142031520278123,-0.8213733408650279400457,...
            -0.6612093864662645136614,-0.4631182124753046121568,-0.2386191860831969086305,0,...
            0.2386191860831969086305,0.4631182124753046121568,0.6612093864662645136614,...
            0.8213733408650279400457,0.9324695142031520278123,0.9887032026126788575047];
        weights = [0.030396154119819768852,0.0836944404469066261328,0.1373206046344469230872,...
            0.181071994323137615187,0.213209652271962279163,0.233770864116994406623,...
            0.2410725801734647619106,0.233770864116994406623,0.213209652271962279163,...
            0.181071994323137615187,0.1373206046344469230872,0.0836944404469066261328,...
            0.030396154119819768852];
        max_divs = 12;
        
    elseif k == 15
        nodes = [-0.991455371120813,-0.949107912342759,-0.864864423359769,...
            -0.741531185599394,-0.586087235467691,-0.405845151377397,...
            -0.207784955007898,0.000000000000000,0.207784955007898,...
            0.405845151377397,0.586087235467691,0.741531185599394,...
            0.864864423359769,0.949107912342759,0.991455371120813];
        weights = [0.022935322010529,0.063092092629979,0.104790010322250,...
            0.140653259715525,0.169004726639267,0.190350578064785,...
            0.204432940075298,0.209482141084728,0.204432940075298,...
            0.190350578064785,0.169004726639267,0.140653259715525,...
            0.104790010322250,0.063092092629979,0.022935322010529];
        max_divs = 12;
    end
    
    n = [0,1];
    y = grid(i,j).location(2) + grid(i,j).edge_lengths(2)/2;
    intervals = [grid(i,j).location(1) - grid(i,j).edge_lengths(1)/2, grid(i,j).location(1) + grid(i,j).edge_lengths(1)/2];
    
    [currents,error,evals] = true_current(grid,i,j,y,n,q,r_s,source_gp,nodes,weights,0,intervals,0.0,[],0.0,max_er,max_divs,0,[],[],[],f);
    
    figsize = [50 50 800 600];
    fontsize = 15;
    gridlines = 1;
    %f = f + 1;
    
    if f == f_int
        figure(f_int)
        clf(f_int)
        set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
        loglog(evals,error,'x-')
        xlabel('Number of Rays')
        ylabel('$\frac{|J_{N}-J_{N-1}|}{J_{N}}$','interpreter','latex','fontsize',20)
        title(sprintf('Current Convergence - Zone (%i,%i)',i,j))
        f = f + 1;
    else
        figure(f_int)
        hold on
        loglog(evals,error,'x-')
        hold off
        if k == 15
            legend('3','5','7','9','11','13','15')
        end
    end
    
    % figure(f)
    % clf(f)
    % set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    % %semilogy(evals,currents,'x-')
    % loglog(evals,currents,'x-')
    % xlabel('Number of Rays')
    % ylabel('Current')
    % f = f + 1;
    
%     figure(f)
%     clf(f)
%     set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
%     %semilogy(evals,error,'x-')
%     loglog(evals,error,'x-')
%     xlabel('Number of Rays')
%     ylabel('$\frac{|J_{N}-J_{N-1}|}{J_{N}}$','interpreter','latex','fontsize',20)
%     title(sprintf('Current Convergence - %i Rays per Division - Zone (%i,%i)',k,i,j))
%     f = f + 1;
    
    % figure(7)
    % set(gcf,'Position', [50 50 800 600],'DefaultAxesFontSize',15)
    % semilogy((ints(2:end)+ints(1:end-1))/2,approx./(ints(2:end)-ints(1:end-1)),'-')
end


function [currents,errors,evals] = true_current(grid,i,j,xy,n,q,r_s,source_gp,...
    nodes,weights,bad_ints,ints,approx,prev_ints,prev_approx,max_er,max_divs,divs,currents,errors,evals,f)

    for m = 1:length(ints)-1
        if bad_ints(m) == 0
            sub_nodes = 1/2*(1+nodes)*(ints(m+1) - ints(m)) + ints(m);
            sub_weights = 1/2*weights*(ints(m+1) - ints(m));
            f_eval = zeros(1,length(sub_nodes));
            for k = 1:length(sub_nodes)
                if n(2) == 0 %if n is horiz, d is the x coord
                    r = [xy,sub_nodes(k)];
                else %if n is vert, d is the y coord
                    r = [sub_nodes(k),xy];
                end
                R = sqrt(sum((r-r_s).^2));
                sigma_bar = average_xs(r,r_s,source_gp,grid,i,j);
                f_eval(k) = q*exp(-sigma_bar*R)/R * dot(n,(r-r_s)/R);
            end
            approx(m) = sum(sub_weights.*f_eval);
        end
    end

    total_current = sum(approx)/(ints(end)-ints(1));    %might need a lengths
    prev_total_current = sum(prev_approx)/(ints(end)-ints(1));

    %if the current intervals solution has converged, add it to approx and continue to next interval
    er = abs(total_current - prev_total_current)/total_current;
    currents(divs+1) = total_current;
    errors(divs+1) = er;
    evals(divs+1) = length(approx)*length(nodes);
    
    %if length(ints) > 2 && (er <= max_er || divs >= max_divs)
    if length(ints) > 2 && (er <= 1e-14 || divs >= max_divs)
        return
    else
        new_ints = ints(1);
        new_approx = approx(1);
        bad_ints = bad_ints*0;  %technically unnecessary
        if length(ints) == 2    %initial interval
            new_ints = [ints(1), ints(1) + 1/2*(ints(2)-ints(1)), ints(2)];
            new_approx = [0,0];
            bad_ints = [0,0];
        else
            count1 = 2; %ints counter
            count2 = 2; %new_ints counter
            %Identify bad sub-intervals and sub-divide them
            for p = 2:length(prev_ints)
                %no sub-division previously, so already know it converged
                if prev_ints(p) == ints(count1)
                    new_ints(count2) = ints(count1);
                    new_approx(count2-1) = approx(count1-1);
                    bad_ints(count2-1) = 1;
                    count1 = count1 + 1;
                    count2 = count2 + 1;

                    %sub-division occured last iteration
                else
                    er = abs(prev_approx(p-1)-approx(count1-1)-approx(count1))/(approx(count1-1)-approx(count1));
                    if er >= max_er
                        new_ints(count2:count2+3) = [ints(count1)-1/2*(ints(count1)-ints(count1-1)), ints(count1), ints(count1)+1/2*(ints(count1+1)-ints(count1)), ints(count1+1)];
                        new_approx(count2-1:count2+2) = [0,0,0,0];
                        bad_ints(count2-1:count2+2) = [0,0,0,0];
                        count1 = count1 + 2;
                        count2 = count2 + 4;
                    else
                        new_ints(count2:count2+1) = [ints(count1),ints(count1+1)];
                        new_approx(count2-1:count2) = [approx(count1-1),approx(count1)];
                        bad_ints(count2-1:count2) = [1,1];
                        count1 = count1 + 2;
                        count2 = count2 + 2;
                    end
                end
            end
        end
        
%         if divs == 2
%             figure(f)
%             set(gcf,'Position', [50 50 800 600],'DefaultAxesFontSize',15)
%             semilogy((ints(2:end)+ints(1:end-1))/2, approx./(ints(2:end)-ints(1:end-1)), '-')
%         elseif divs > 2 && divs < 8 && rem(divs,2) == 0
%             hold on
%             semilogy((ints(2:end)+ints(1:end-1))/2, approx./(ints(2:end)-ints(1:end-1)), '-')
%             hold off
%         end
        
        divs = divs + 1;
        [currents,errors,evals] = true_current(grid,i,j,xy,n,q,r_s,source_gp,nodes,weights,bad_ints,new_ints,new_approx,ints,approx,max_er,max_divs,divs,currents,errors,evals,f);
    end
end


