clear

N_min = 2;
N_max = 22;
N_quad = 4; 
N_rays = 3;
quad_method = 'Gauss';
q = 1.0e6;
L = 1.0;
H = 1.0;
source_loc = [0,0];

max_er = 1e-14;
max_loc_er = 1e-8;
max_divs = 10;
load_soln = 0;

neg_fix = 0;

interp = 0;
N_angles = 4; %Interp points (rays cast)
interp_method = 'spline';
interp_case = 'SB';

%N_zones_list = N_min:2:N_max;
%N_zones_list = [6,10,16,20,30,40,50];
N_zones_list = [6,10,16,20,28,36,44,52];

warning('off','MATLAB:MKDIR:DirectoryExists')
warning('off','MATLAB:polyfit:RepeatedPointsOrRescale')


error_11 = zeros(length(N_zones_list),2);  %L1 error
error_12 = zeros(length(N_zones_list),2);
error_22 = zeros(length(N_zones_list),2);
error_total = zeros(length(N_zones_list),2);
error_11_R = zeros(length(N_zones_list),2);  %L1 error x R
error_12_R = zeros(length(N_zones_list),2);
error_22_R = zeros(length(N_zones_list),2);
error_total_R = zeros(length(N_zones_list),2);
error_top_right = zeros(length(N_zones_list),2);   %rel error
error_top_left = zeros(length(N_zones_list),2);
error_bot_left = zeros(length(N_zones_list),2);

counter = 1;
for N_zones = N_zones_list
    num_zones = [N_zones,N_zones];
    
    addpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
    addpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
    addpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))
    
    grid_surf = ray_tracing_negfix(num_zones,q,N_quad,[L,H],quad_method,source_loc,neg_fix);
    
    if N_zones >= 28
        load(sprintf('.\\true_solutions\\true_soln__%d_zones.mat',num_zones(1)),'grid_true');
    else
        grid_true = true_solution(grid_surf,q,source_loc,max_er,max_loc_er,max_divs);
    end
    
    rmpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
    rmpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
    rmpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))
    
    addpath(strcat(pwd,'\\Functions_interior\\General_Functions'))
    addpath(strcat(pwd,'\\Functions_interior\\Case_Functions'))
    addpath(strcat(pwd,'\\Functions_interior\\Ray_Tracing'))
    
    grid_int = ray_tracing(num_zones,q,N_rays,[L,H],quad_method,source_loc);
    
    rmpath(strcat(pwd,'\\Functions_interior\\General_Functions'))
    rmpath(strcat(pwd,'\\Functions_interior\\Case_Functions'))
    rmpath(strcat(pwd,'\\Functions_interior\\Ray_Tracing'))
    
    
    
    tot_11 = 0.0;
    tot_11_R = 0.0;
    for i = 1:N_zones/2
        for j = 1:N_zones/2
            error_11(counter,1) = error_11(counter,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
            error_11(counter,2) = error_11(counter,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
            tot_11 = tot_11 + grid_true(i,j).avg_N_absorb;
            error_11_R(counter,1) = error_11_R(counter,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*sqrt(grid_surf(i,j).location(1)^2+grid_surf(i,j).location(2)^2);
            error_11_R(counter,2) = error_11_R(counter,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*sqrt(grid_int(i,j).location(1)^2+grid_int(i,j).location(2)^2);
            tot_11_R = tot_11_R + grid_true(i,j).avg_N_absorb*sqrt(grid_surf(i,j).location(1)^2+grid_surf(i,j).location(2)^2);
        end
    end
    error_11(counter,:) = error_11(counter,:)/tot_11;
    error_11_R(counter,:) = error_11_R(counter,:)/tot_11_R;
    
    tot_12 = 0.0;
    tot_12_R = 0.0;
    for i = 1:N_zones/2
        for j = N_zones/2:N_zones
            error_12(counter,1) = error_12(counter,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
            error_12(counter,2) = error_12(counter,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
            tot_12 = tot_12 + grid_true(i,j).avg_N_absorb;
            error_12_R(counter,1) = error_12_R(counter,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*sqrt(grid_surf(i,j).location(1)^2+grid_surf(i,j).location(2)^2);
            error_12_R(counter,2) = error_12_R(counter,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*sqrt(grid_int(i,j).location(1)^2+grid_int(i,j).location(2)^2);
            tot_12_R = tot_12_R + grid_true(i,j).avg_N_absorb*sqrt(grid_surf(i,j).location(1)^2+grid_surf(i,j).location(2)^2);
        end
    end
    error_12(counter,:) = error_12(counter,:)/tot_12;
    error_12_R(counter,:) = error_12_R(counter,:)/tot_12_R;

    tot_22 = 0.0;
    tot_22_R = 0.0;
    for i = N_zones/2:N_zones
        for j = N_zones/2:N_zones
            error_22(counter,1) = error_22(counter,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
            error_22(counter,2) = error_22(counter,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
            tot_22 = tot_22 + grid_true(i,j).avg_N_absorb;
            error_22_R(counter,1) = error_22_R(counter,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*sqrt(grid_surf(i,j).location(1)^2+grid_surf(i,j).location(2)^2);
            error_22_R(counter,2) = error_22_R(counter,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*sqrt(grid_int(i,j).location(1)^2+grid_int(i,j).location(2)^2);
            tot_22_R = tot_22_R + grid_true(i,j).avg_N_absorb*sqrt(grid_surf(i,j).location(1)^2+grid_surf(i,j).location(2)^2);
        end
    end
    error_22(counter,:) = error_22(counter,:)/tot_22;
    error_22_R(counter,:) = error_22_R(counter,:)/tot_22_R;
    
    tot = 0.0;
    tot_R = 0.0;
    for i = 1:N_zones
        for j = 1:N_zones
            error_total(counter,1) = error_total(counter,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
            error_total(counter,2) = error_total(counter,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
            tot = tot + grid_true(i,j).avg_N_absorb;
            error_total_R(counter,1) = error_total_R(counter,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*sqrt(grid_surf(i,j).location(1)^2+grid_surf(i,j).location(2)^2);
            error_total_R(counter,2) = error_total_R(counter,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*sqrt(grid_int(i,j).location(1)^2+grid_int(i,j).location(2)^2);
            tot_R = tot_R + grid_true(i,j).avg_N_absorb*sqrt(grid_surf(i,j).location(1)^2+grid_surf(i,j).location(2)^2);
        end
    end
    error_total(counter,:) = error_total(counter,:)/tot;
    error_total_R(counter,:) = error_total_R(counter,:)/tot_R;
    
    error_bot_left(counter) = abs(grid_surf(1,1).avg_N_absorb - grid_true(1,1).avg_N_absorb)/grid_true(1,1).avg_N_absorb;
    error_top_left(counter) = abs(grid_surf(1,N_zones).avg_N_absorb - grid_true(1,N_zones).avg_N_absorb)/grid_true(1,N_zones).avg_N_absorb;
    error_top_right(counter) = abs(grid_surf(N_zones,N_zones).avg_N_absorb - grid_true(N_zones,N_zones).avg_N_absorb)/grid_true(N_zones,N_zones).avg_N_absorb;

    counter = counter + 1;
end




f = 1000;
figsize = [50 50 800 600];
fontsize = 15;
gridlines = 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,error_11(:,1),'-x')
hold on
semilogy(1./N_zones_list,error_11(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error')
title(sprintf('L1 Error in Quadrant (1,1) - %i Rays',N_quad))
legend('Surf','Int')
%extra_axes_2(1,N_min/2,N_max/2);
save_plot(figure(f),'Runs\\quad_conv\\quad_11',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,transpose(error_11(:,1))./(N_zones_list/2).^2,'-x')
hold on
semilogy(1./N_zones_list,transpose(error_11(:,2))./(N_zones_list/2).^2,'-x')
hold off
xlabel('dx')
ylabel('L1 Error / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (1,1) - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_11_norm',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,error_11_R(:,1),'-x')
hold on
semilogy(1./N_zones_list,error_11_R(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error x R')
%ylim([1e-3,1e-2])
title(sprintf('L1 Error in Quadrant (1,1) x R - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_11_R',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list, transpose(error_11_R(:,1))./(N_zones_list/2).^2, '-x')
hold on
semilogy(1./N_zones_list, transpose(error_11_R(:,2))./(N_zones_list/2).^2, '-x')
hold off
xlabel('dx')
ylabel('L1 Error x R / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (1,1) x R - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_11_R_norm',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,error_12(:,1),'-x')
hold on
semilogy(1./N_zones_list,error_12(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error')
title(sprintf('L1 Error in Quadrant (1,2) - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_12',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,transpose(error_12(:,1))./(N_zones_list/2).^2,'-x')
hold on
semilogy(1./N_zones_list,transpose(error_12(:,2))./(N_zones_list/2).^2,'-x')
hold off
xlabel('dx')
ylabel('L1 Error / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (1,2) - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_12_norm',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,error_12_R(:,1),'-x')
hold on
semilogy(1./N_zones_list,error_12_R(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error x R')
%ylim([1e-3,1e-2])
title(sprintf('L1 Error in Quadrant (1,2) x R - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_12_R',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list, transpose(error_12_R(:,1))./(N_zones_list/2).^2, '-x')
hold on
semilogy(1./N_zones_list, transpose(error_12_R(:,2))./(N_zones_list/2).^2, '-x')
hold off
xlabel('dx')
ylabel('L1 Error x R / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (1,2) x R - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_12_R_norm',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,error_22(:,1),'-x')
hold on
semilogy(1./N_zones_list,error_22(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error')
title(sprintf('L1 Error in Quadrant (2,2) - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_22',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,transpose(error_22(:,1))./(N_zones_list/2).^2,'-x')
hold on
semilogy(1./N_zones_list,transpose(error_22(:,2))./(N_zones_list/2).^2,'-x')
hold off
xlabel('dx')
ylabel('L1 Error / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (2,2) - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_22_norm',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,error_22_R(:,1),'-x')
hold on
semilogy(1./N_zones_list,error_22_R(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error x R')
%ylim([1e-3,1e-2])
title(sprintf('L1 Error in Quadrant (2,2) x R - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_22_R',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list, transpose(error_22_R(:,1))./(N_zones_list/2).^2, '-x')
hold on
semilogy(1./N_zones_list, transpose(error_22_R(:,2))./(N_zones_list/2).^2, '-x')
hold off
xlabel('dx')
ylabel('L1 Error x R / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (2,2) x R - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_22_R_norm',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,error_total(:,1),'-x')
hold on
semilogy(1./N_zones_list,error_total(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error')
title(sprintf('Total L1 Error - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\total',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,transpose(error_total(:,1))./(N_zones_list/2).^2,'-x')
hold on
semilogy(1./N_zones_list,transpose(error_total(:,2))./(N_zones_list/2).^2,'-x')
hold off
xlabel('dx')
ylabel('L1 Error / Number of Zones')
title(sprintf('Normalized Total L1 Error - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\total_norm',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list,error_total_R(:,1),'-x')
hold on
semilogy(1./N_zones_list,error_total_R(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error x R')
%ylim([1e-3,1e-2])
title(sprintf('Total L1 Error x R - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\total_R',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list, transpose(error_total_R(:,1))./(N_zones_list/2).^2, '-x')
hold on
semilogy(1./N_zones_list, transpose(error_total_R(:,2))./(N_zones_list/2).^2, '-x')
hold off
xlabel('dx')
ylabel('L1 Error x R / Number of Zones')
title(sprintf('Normalized Total L1 Error x R - %i Rays',N_quad))
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\total_R_norm',1)
f = f + 1;


figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list, error_bot_left, '-x')
%semilogy(N_zones_list.^2, error_bot_left, '-x')
xlabel('dx')
ylabel('Relative Error')
title('Relative Error in Zone (1,1)')
save_plot(figure(f),'Runs\\quad_conv\\rel_error_BL',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list, error_top_left, '-x')
%semilogy(N_zones_list.^2, error_top_left, '-x')
xlabel('dx')
ylabel('Relative Error')
title('Relative Error in Zone (1,N-max)')
save_plot(figure(f),'Runs\\quad_conv\\rel_error_TL',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
semilogy(1./N_zones_list, error_top_right, '-x')
%semilogy(N_zones_list.^2, error_top_right, '-x')
xlabel('dx')
ylabel('Relative Error')
title('Relative Error in Zone (N-max,N-max)')
save_plot(figure(f),'Runs\\quad_conv\\rel_error_TR',1)
f = f + 1;



figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,error_11(:,1),'-x')
hold on
loglog(1./N_zones_list,error_11(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error')
title(sprintf('L1 Error in Quadrant (1,1) - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
%extra_axes_2(1,N_min/2,N_max/2);
save_plot(figure(f),'Runs\\quad_conv\\quad_11_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,transpose(error_11(:,1))./(N_zones_list/2).^2,'-x')
hold on
loglog(1./N_zones_list,transpose(error_11(:,2))./(N_zones_list/2).^2,'-x')
hold off
xlabel('dx')
ylabel('L1 Error / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (1,1) - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_11_norm_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,error_11_R(:,1),'-x')
hold on
loglog(1./N_zones_list,error_11_R(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error x R')
%ylim([1e-3,1e-2])
title(sprintf('L1 Error in Quadrant (1,1) x R - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_11_R_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list, transpose(error_11_R(:,1))./(N_zones_list/2).^2, '-x')
hold on
loglog(1./N_zones_list, transpose(error_11_R(:,2))./(N_zones_list/2).^2, '-x')
hold off
xlabel('dx')
ylabel('L1 Error x R / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (1,1) x R - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_11_R_norm_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,error_12(:,1),'-x')
hold on
loglog(1./N_zones_list,error_12(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error')
title(sprintf('L1 Error in Quadrant (1,2) - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_12_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,transpose(error_12(:,1))./(N_zones_list/2).^2,'-x')
hold on
loglog(1./N_zones_list,transpose(error_12(:,2))./(N_zones_list/2).^2,'-x')
hold off
xlabel('dx')
ylabel('L1 Error / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (1,2) - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_12_norm_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,error_12_R(:,1),'-x')
hold on
loglog(1./N_zones_list,error_12_R(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error x R')
%ylim([1e-3,1e-2])
title(sprintf('L1 Error in Quadrant (1,2) x R - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_12_R_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list, transpose(error_12_R(:,1))./(N_zones_list/2).^2, '-x')
hold on
loglog(1./N_zones_list, transpose(error_12_R(:,2))./(N_zones_list/2).^2, '-x')
hold off
xlabel('dx')
ylabel('L1 Error x R / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (1,2) x R - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_12_R_norm_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,error_22(:,1),'-x')
hold on
loglog(1./N_zones_list,error_22(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error')
title(sprintf('L1 Error in Quadrant (2,2) - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_22_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,transpose(error_22(:,1))./(N_zones_list/2).^2,'-x')
hold on
loglog(1./N_zones_list,transpose(error_22(:,2))./(N_zones_list/2).^2,'-x')
hold off
xlabel('dx')
ylabel('L1 Error / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (2,2) - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_22_norm_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,error_22_R(:,1),'-x')
hold on
loglog(1./N_zones_list,error_22_R(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error x R')
%ylim([1e-3,1e-2])
title(sprintf('L1 Error in Quadrant (2,2) x R - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_22_R_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list, transpose(error_22_R(:,1))./(N_zones_list/2).^2, '-x')
hold on
loglog(1./N_zones_list, transpose(error_22_R(:,2))./(N_zones_list/2).^2, '-x')
hold off
xlabel('dx')
ylabel('L1 Error x R / Number of Zones')
title(sprintf('Normalized L1 Error in Quadrant (2,2) x R - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\quad_22_R_norm_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,error_total(:,1),'-x')
hold on
loglog(1./N_zones_list,error_total(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error')
title(sprintf('Total L1 Error - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\total_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,transpose(error_total(:,1))./(N_zones_list/2).^2,'-x')
hold on
loglog(1./N_zones_list,transpose(error_total(:,2))./(N_zones_list/2).^2,'-x')
hold off
xlabel('dx')
ylabel('L1 Error / Number of Zones')
title(sprintf('Normalized Total L1 Error - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\total_norm_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list,error_total_R(:,1),'-x')
hold on
loglog(1./N_zones_list,error_total_R(:,2),'-x')
hold off
xlabel('dx')
ylabel('L1 Error x R')
%ylim([1e-3,1e-2])
title(sprintf('Total L1 Error x R - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\total_R_loglog',1)
f = f + 1;

figure(f)
clf(f)
set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
loglog(1./N_zones_list, transpose(error_total_R(:,1))./(N_zones_list/2).^2, '-x')
hold on
loglog(1./N_zones_list, transpose(error_total_R(:,2))./(N_zones_list/2).^2, '-x')
hold off
xlabel('dx')
ylabel('L1 Error x R / Number of Zones')
title(sprintf('Normalized Total L1 Error x R - %i Rays',N_quad))
xlim([1e-2,1e0])
legend('Surf','Int')
save_plot(figure(f),'Runs\\quad_conv\\total_R_norm_loglog',1)
f = f + 1;






