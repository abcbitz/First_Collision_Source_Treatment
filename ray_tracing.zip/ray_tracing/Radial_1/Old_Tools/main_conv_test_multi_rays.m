clear

N_min = 2;
N_max = 22;
N_rays_surf = [2,4,8,12]; 
N_rays_int = [2,3,4,5]; 
%N_zones_list = [6,12,18,24,30,36,42,48,54];
%N_zones_list = [12,20,28,36,44,52];
N_zones_list = [10,12,15,20,25,28,30,36,40,44,52];
%N_zones_list = [6,18,30,42,54];

show_threshold = 1;
quad_method = 'Gauss';
q = 1.0e6;
L = 1.0;
H = 1.0;
source_loc = [0,0];

max_er = 1e-12;
max_loc_er = 1e-8;
max_divs = 10;
load_soln = 0;

neg_fix = 0;


warning('off','MATLAB:MKDIR:DirectoryExists')
warning('off','MATLAB:polyfit:RepeatedPointsOrRescale')

%dim 3 - (quads 11,12,21,22,tot)
error_surf = zeros(length(N_zones_list), length(N_rays_surf), 5);
error_int = zeros(length(N_zones_list), length(N_rays_int), 5);
error_R_surf = zeros(length(N_zones_list), length(N_rays_surf), 5);
error_R_int = zeros(length(N_zones_list), length(N_rays_int), 5);

for m = 1:length(N_zones_list)
    N_zones = N_zones_list(m);
    num_zones = [N_zones,N_zones];
    
    addpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
    addpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
    addpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))
    grid = build_grid(num_zones,[L,H]);
    grid_true = true_solution(grid,q,source_loc,max_er,max_loc_er,max_divs);
    %load(sprintf('.\\true_solutions\\true_soln__%d_zones.mat',num_zones(1)),'grid_true');
    rmpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
    rmpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
    rmpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))
    
    for n = 1:length(N_rays_surf)
        addpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
        addpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
        addpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))
        grid_surf = ray_tracing_negfix(num_zones,q,N_rays_surf(n),[L,H],quad_method,source_loc,neg_fix);
        rmpath(strcat(pwd,'\\Functions_surface\\General_Functions'))
        rmpath(strcat(pwd,'\\Functions_surface\\Case_Functions'))
        rmpath(strcat(pwd,'\\Functions_surface\\Ray_Tracing'))
        
        tot = zeros(1,1,5);
        tot_R = zeros(1,1,5);
        for i = 1:N_zones
            for j = 1:N_zones
                R = sqrt(grid_surf(i,j).location(1)^2+grid_surf(i,j).location(2)^2);
                
                if i <= N_zones/2 && j <= N_zones/2     %11
                    error_surf(m,n,1) = error_surf(m,n,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                    tot(1) = tot(1) + grid_true(i,j).avg_N_absorb;
                    error_R_surf(m,n,1) = error_R_surf(m,n,1) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                    tot_R(1) = tot_R(1) + grid_true(i,j).avg_N_absorb*R;
                    
                elseif i <= N_zones/2 && j > N_zones/2  %12
                    error_surf(m,n,2) = error_surf(m,n,2) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                    tot(2) = tot(2) + grid_true(i,j).avg_N_absorb;
                    error_R_surf(m,n,2) = error_R_surf(m,n,2) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                    tot_R(2) = tot_R(2) + grid_true(i,j).avg_N_absorb*R;
                    
                elseif i > N_zones/2 && j <= N_zones/2  %21
                    error_surf(m,n,3) = error_surf(m,n,3) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                    tot(3) = tot(3) + grid_true(i,j).avg_N_absorb;
                    error_R_surf(m,n,3) = error_R_surf(m,n,3) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                    tot_R(3) = tot_R(3) + grid_true(i,j).avg_N_absorb*R;
                    
                elseif i > N_zones/2 && j > N_zones/2   %22
                    error_surf(m,n,4) = error_surf(m,n,4) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                    tot(4) = tot(4) + grid_true(i,j).avg_N_absorb;
                    error_R_surf(m,n,4) = error_R_surf(m,n,4) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                    tot_R(4) = tot_R(4) + grid_true(i,j).avg_N_absorb*R;
                end
                
                %tot
                error_surf(m,n,5) = error_surf(m,n,5) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                tot(5) = tot(5) + grid_true(i,j).avg_N_absorb;
                error_R_surf(m,n,5) = error_R_surf(m,n,5) + abs(grid_surf(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                tot_R(5) = tot_R(5) + grid_true(i,j).avg_N_absorb*R;
            end
        end
        
        error_surf(m,n,:) = error_surf(m,n,:)./tot;
        error_R_surf(m,n,:) = error_R_surf(m,n,:)./tot_R;
    end

    
    for n = 1:length(N_rays_int)
        addpath(strcat(pwd,'\\Functions_interior\\General_Functions'))
        addpath(strcat(pwd,'\\Functions_interior\\Case_Functions'))
        addpath(strcat(pwd,'\\Functions_interior\\Ray_Tracing'))
        grid_int = ray_tracing(num_zones,q,N_rays_int(n),[L,H],quad_method,source_loc);
        rmpath(strcat(pwd,'\\Functions_interior\\General_Functions'))
        rmpath(strcat(pwd,'\\Functions_interior\\Case_Functions'))
        rmpath(strcat(pwd,'\\Functions_interior\\Ray_Tracing'))
         
        tot = zeros(1,1,5);
        tot_R = zeros(1,1,5);
        for i = 1:N_zones
            for j = 1:N_zones
                R = sqrt(grid_int(i,j).location(1)^2+grid_int(i,j).location(2)^2);
                
                if i <= N_zones/2 && j <= N_zones/2     %11
                    error_int(m,n,1) = error_int(m,n,1) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                    tot(1) = tot(1) + grid_true(i,j).avg_N_absorb;
                    error_R_int(m,n,1) = error_R_int(m,n,1) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                    tot_R(1) = tot_R(1) + grid_true(i,j).avg_N_absorb*R;
                    
                elseif i <= N_zones/2 && j > N_zones/2  %12
                    error_int(m,n,2) = error_int(m,n,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                    tot(2) = tot(2) + grid_true(i,j).avg_N_absorb;
                    error_R_int(m,n,2) = error_R_int(m,n,2) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                    tot_R(2) = tot_R(2) + grid_true(i,j).avg_N_absorb*R;
                    
                elseif i > N_zones/2 && j <= N_zones/2  %21
                    error_int(m,n,3) = error_int(m,n,3) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                    tot(3) = tot(3) + grid_true(i,j).avg_N_absorb;
                    error_R_int(m,n,3) = error_R_int(m,n,3) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                    tot_R(3) = tot_R(3) + grid_true(i,j).avg_N_absorb*R;
                    
                elseif i > N_zones/2 && j > N_zones/2   %22
                    error_int(m,n,4) = error_int(m,n,4) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                    tot(4) = tot(4) + grid_true(i,j).avg_N_absorb;
                    error_R_int(m,n,4) = error_R_int(m,n,4) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                    tot_R(4) = tot_R(4) + grid_true(i,j).avg_N_absorb*R;
                end
                
                %tot
                error_int(m,n,5) = error_int(m,n,5) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb);
                tot(5) = tot(5) + grid_true(i,j).avg_N_absorb;
                error_R_int(m,n,5) = error_R_int(m,n,5) + abs(grid_int(i,j).avg_N_absorb - grid_true(i,j).avg_N_absorb)*R;
                tot_R(5) = tot_R(5) + grid_true(i,j).avg_N_absorb*R;
            end
        end
        
        error_int(m,n,:) = error_int(m,n,:)./tot;
        error_R_int(m,n,:) = error_R_int(m,n,:)./tot_R;
    end
 end

save('Runs\\quad_conv\\data')

f = 1000;
figsize = [50 50 800 600];
fontsize = 15;
gridlines = 1;

leg_rays = cell(length(N_rays_int)+length(N_rays_surf),1);
for i = 1:length(N_rays_int)
    leg_rays{i} = sprintf('Int - %d rays/zone', N_rays_int(i)^2);
end
for i = 1:length(N_rays_surf)
    leg_rays{i+length(N_rays_int)} = sprintf('Surf - %d rays/zone', 2*N_rays_surf(i)); 
end
leg_rays{end+1} = 'True Soln Tolerance';


str_list = {'Quad (1,1)', 'Quad (1,2)', 'Quad (2,1)', 'Quad (2,2)', 'All Quads'};
str_list_2 = {'quad_11','quad_12','quad_21','quad_22','tot'};

for i = 1:5
    figure(f)
    clf(f)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    semilogy(1./N_zones_list,error_int(:,1,i),'-x')
    hold on
    for n = 2:length(N_rays_int)
        semilogy(1./N_zones_list,error_int(:,n,i),'-x')
    end
    for n = 1:length(N_rays_surf)
        semilogy(1./N_zones_list,error_surf(:,n,i),'-o')
    end
    if show_threshold == 1
        semilogy(1./N_zones_list,ones(length(N_zones_list),1)*max_er,'--','color','black')
    end
    hold off
    xlabel('dx')
    ylabel('L1 Error')
    title(sprintf('L1 Error in %s',str_list{i}))
    legend(leg_rays,'Location','southoutside','NumColumns',3)
    save_plot(figure(f),sprintf('Runs\\quad_conv\\%s',str_list_2{i}),1)
    f = f + 1;
    
    figure(f)
    clf(f)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    semilogy(1./N_zones_list,error_int(:,1,i)./transpose(N_zones_list/2).^2,'-x')
    hold on
    for n = 2:length(N_rays_int)
        semilogy(1./N_zones_list,error_int(:,n,i)./transpose(N_zones_list/2).^2,'-x')
    end
    for n = 1:length(N_rays_surf)
        semilogy(1./N_zones_list,error_surf(:,n,i)./transpose(N_zones_list/2).^2,'-o')
    end
    if show_threshold == 1
        semilogy(1./N_zones_list,ones(length(N_zones_list),1)*max_er,'--','color','black')
    end
    hold off
    xlabel('dx')
    ylabel('L1 Error / Number of Zones')
    title(sprintf('Normalized L1 Error in %s',str_list{i}))
    legend(leg_rays,'Location','southoutside','NumColumns',3)
    save_plot(figure(f),sprintf('Runs\\quad_conv\\%s_norm',str_list_2{i}),1)
    f = f + 1;
    
    figure(f)
    clf(f)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    semilogy(1./N_zones_list,error_R_int(:,1,i),'-x')
    hold on
    for n = 2:length(N_rays_int)
        semilogy(1./N_zones_list,error_R_int(:,n,i),'-x')
    end
    for n = 1:length(N_rays_surf)
        semilogy(1./N_zones_list,error_R_surf(:,n,i),'-o')
    end
    if show_threshold == 1
        semilogy(1./N_zones_list,ones(length(N_zones_list),1)*max_er,'--','color','black')
    end
    hold off
    xlabel('dx')
    ylabel('L1 Error x R')
    title(sprintf('L1 Error x R in %s',str_list{i}))
    legend(leg_rays,'Location','southoutside','NumColumns',3)
    save_plot(figure(f),sprintf('Runs\\quad_conv\\%s_R',str_list_2{i}),1)
    f = f + 1;
    
    figure(f)
    clf(f)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    semilogy(1./N_zones_list,error_R_int(:,1,i)./transpose(N_zones_list/2).^2,'-x')
    hold on
    for n = 2:length(N_rays_int)
        semilogy(1./N_zones_list,error_R_int(:,n,i)./transpose(N_zones_list/2).^2,'-x')
    end
    for n = 1:length(N_rays_surf)
        semilogy(1./N_zones_list,error_R_surf(:,n,i)./transpose(N_zones_list/2).^2,'-o')
    end
    if show_threshold == 1
        semilogy(1./N_zones_list,ones(length(N_zones_list),1)*max_er,'--','color','black')
    end
    hold off
    xlabel('dx')
    ylabel('(L1 Error x R) / Number of Zones')
    title(sprintf('Normalized L1 Error x R in %s',str_list{i}))
    legend(leg_rays,'Location','southoutside','NumColumns',3)
    save_plot(figure(f),sprintf('Runs\\quad_conv\\%s_R_norm',str_list_2{i}),1)
    f = f + 1;
    
    
    figure(f)
    clf(f)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    loglog(1./N_zones_list,error_int(:,1,i),'-x')
    hold on
    for n = 2:length(N_rays_int)
        loglog(1./N_zones_list,error_int(:,n,i),'-x')
    end
    for n = 1:length(N_rays_surf)
        loglog(1./N_zones_list,error_surf(:,n,i),'-o')
    end
    if show_threshold == 1
        loglog(1./N_zones_list,ones(length(N_zones_list),1)*max_er,'--','color','black')
    end
    hold off
    xlabel('dx')
    ylabel('L1 Error')
    title(sprintf('L1 Error in %s',str_list{i}))
    legend(leg_rays,'Location','southoutside','NumColumns',3)
    save_plot(figure(f),sprintf('Runs\\quad_conv\\%s_loglog',str_list_2{i}),1)
    f = f + 1;
    
    figure(f)
    clf(f)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    loglog(1./N_zones_list,error_int(:,1,i)./transpose(N_zones_list/2).^2,'-x')
    hold on
    for n = 2:length(N_rays_int)
        loglog(1./N_zones_list,error_int(:,n,i)./transpose(N_zones_list/2).^2,'-x')
    end
    for n = 1:length(N_rays_surf)
        loglog(1./N_zones_list,error_surf(:,n,i)./transpose(N_zones_list/2).^2,'-o')
    end
    if show_threshold == 1
        loglog(1./N_zones_list,ones(length(N_zones_list),1)*max_er,'--','color','black')
    end
    hold off
    xlabel('dx')
    ylabel('L1 Error / Number of Zones')
    title(sprintf('Normalized L1 Error in %s',str_list{i}))
    legend(leg_rays,'Location','southoutside','NumColumns',3)
    save_plot(figure(f),sprintf('Runs\\quad_conv\\%s_norm_loglog',str_list_2{i}),1)
    f = f + 1;
    
    figure(f)
    clf(f)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    loglog(1./N_zones_list,error_R_int(:,1,i),'-x')
    hold on
    for n = 2:length(N_rays_int)
        loglog(1./N_zones_list,error_R_int(:,n,i),'-x')
    end
    for n = 1:length(N_rays_surf)
        loglog(1./N_zones_list,error_R_surf(:,n,i),'-o')
    end
    if show_threshold == 1
        loglog(1./N_zones_list,ones(length(N_zones_list),1)*max_er,'--','color','black')
    end
    hold off
    xlabel('dx')
    ylabel('L1 Error x R')
    title(sprintf('L1 Error x R in %s',str_list{i}))
    legend(leg_rays,'Location','southoutside','NumColumns',3)
    save_plot(figure(f),sprintf('Runs\\quad_conv\\%s_R_loglog',str_list_2{i}),1)
    f = f + 1;
    
    figure(f)
    clf(f)
    set(gcf,'Position', figsize,'DefaultAxesFontSize',fontsize)
    loglog(1./N_zones_list,error_R_int(:,1,i)./transpose(N_zones_list/2).^2,'-x')
    hold on
    for n = 2:length(N_rays_int)
        loglog(1./N_zones_list,error_R_int(:,n,i)./transpose(N_zones_list/2).^2,'-x')
    end
    for n = 1:length(N_rays_surf)
        loglog(1./N_zones_list,error_R_surf(:,n,i)./transpose(N_zones_list/2).^2,'-o')
    end
    if show_threshold == 1
        loglog(1./N_zones_list,ones(length(N_zones_list),1)*max_er,'--','color','black')
    end
    hold off
    xlabel('dx')
    ylabel('(L1 Error x R) / Number of Zones')
    title(sprintf('Normalized L1 Error x R in %s',str_list{i}))
    legend(leg_rays,'Location','southoutside','NumColumns',3)
    save_plot(figure(f),sprintf('Runs\\quad_conv\\%s_R_norm_loglog',str_list_2{i}),1)
    f = f + 1;
end





