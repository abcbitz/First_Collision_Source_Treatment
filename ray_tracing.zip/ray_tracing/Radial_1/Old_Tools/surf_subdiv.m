function grid = surf_subdiv(num_zones,dim,q,r_s,max_er,max_loc_er,max_divs,N_rays_per_div)

    if N_rays_per_div == 3
        nodes = [-0.7745966692414833770359,0.0,0.7745966692414833770359];
        weights = [0.5555555555555555555556,0.8888888888888888888889,0.5555555555555555555556];

    elseif N_rays_per_div == 5
        nodes = [-0.9258200997725514615666,-0.5773502691896257645092,0.0,...
            0.5773502691896257645092,0.9258200997725514615666];
        weights = [0.197979797979797979798,0.4909090909090909090909,0.6222222222222222222222,...
            0.4909090909090909090909,0.197979797979797979798];

    elseif N_rays_per_div == 7
        nodes = [-0.9604912687080202834235,-0.7745966692414833770359,-0.4342437493468025580021,...
            0.0,0.4342437493468025580021,0.7745966692414833770359,0.9604912687080202834235];
        weights = [0.1046562260264672651938,0.2684880898683334407286,...
            0.4013974147759622229051,0.4509165386584741423451,0.4013974147759622229051,...
            0.2684880898683334407286,0.1046562260264672651938];

    elseif N_rays_per_div == 9
        nodes = [-0.9765602507375731115345,-0.861136311594052575224,-0.6402862174963099824047,...
            -0.3399810435848562648027,0,0.3399810435848562648027,0.6402862174963099824047,...
            0.861136311594052575224,0.9765602507375731115345];
        weights = [0.06297737366547301476549,0.1700536053357227268027,0.2667983404522844480328,...
            0.326949189601451629558,0.346442981890136361681,0.326949189601451629558,0.2667983404522844480328,...
            0.1700536053357227268027,0.06297737366547301476549];

    elseif N_rays_per_div == 11
        nodes = [-0.9840853600948424644962,-0.9061798459386639927976,-0.7541667265708492204408,...
            -0.5384693101056830910363,-0.2796304131617831934135,0,0.2796304131617831934135,...
            0.5384693101056830910363,0.7541667265708492204408,0.9061798459386639927976,...
            0.9840853600948424644962];
        weights = [0.04258203675108183286451,0.1152333166224733940246,0.186800796556492657468,...
            0.2410403392286475866999,0.272849801912558922341,0.2829874178574912132043,...
            0.272849801912558922341,0.2410403392286475866999,0.186800796556492657468,...
            0.1152333166224733940246,0.04258203675108183286451];

    elseif N_rays_per_div == 13
        nodes = [-0.9887032026126788575047,-0.9324695142031520278123,-0.8213733408650279400457,...
            -0.6612093864662645136614,-0.4631182124753046121568,-0.2386191860831969086305,0,...
            0.2386191860831969086305,0.4631182124753046121568,0.6612093864662645136614,...
            0.8213733408650279400457,0.9324695142031520278123,0.9887032026126788575047];
        weights = [0.030396154119819768852,0.0836944404469066261328,0.1373206046344469230872,...
            0.181071994323137615187,0.213209652271962279163,0.233770864116994406623,...
            0.2410725801734647619106,0.233770864116994406623,0.213209652271962279163,...
            0.181071994323137615187,0.1373206046344469230872,0.0836944404469066261328,...
            0.030396154119819768852];

    elseif N_rays_per_div == 15
        nodes = [-0.991455371120813,-0.949107912342759,-0.864864423359769,...
            -0.741531185599394,-0.586087235467691,-0.405845151377397,...
            -0.207784955007898,0.000000000000000,0.207784955007898,...
            0.405845151377397,0.586087235467691,0.741531185599394,...
            0.864864423359769,0.949107912342759,0.991455371120813];
        weights = [0.022935322010529,0.063092092629979,0.104790010322250,...
            0.140653259715525,0.169004726639267,0.190350578064785,...
            0.204432940075298,0.209482141084728,0.204432940075298,...
            0.190350578064785,0.169004726639267,0.140653259715525,...
            0.104790010322250,0.063092092629979,0.022935322010529];
    end
    
    [nodes,weights] = lgwt(N_rays_per_div,1,-1);
    nodes = transpose(nodes);
    weights = transpose(-weights);

    s = fprintf(' ');
    grid = build_grid(num_zones,dim);
    source_gp = source_zone(r_s,grid);

    %assumes that source is in bottom left corner
    for i = 1:num_zones(1)
        for j = 1:num_zones(2)
            dx = grid(i,j).edge_lengths(1);
            dy = grid(i,j).edge_lengths(2);

            if i ~= 1
                grid(i,j).total_current(1) = -grid(i-1,j).total_current(3);
            end
            if j ~= 1
                grid(i,j).total_current(2) = -grid(i,j-1).total_current(4);
            end

            %(x,y) is the top right corner of the zone (the far edges)
            %intervals is zone bounds in x or y
            x = grid(i,j).location(1) + grid(i,j).edge_lengths(1)/2;
            intervals = [grid(i,j).location(2) - grid(i,j).edge_lengths(2)/2, grid(i,j).location(2) + grid(i,j).edge_lengths(2)/2];
            grid(i,j).total_current(3) = gauss_kron(grid,i,j,x,[1,0],q,r_s,source_gp,nodes,weights,0,intervals,0.0,[],0.0,0,max_er,max_loc_er,max_divs);

            y = grid(i,j).location(2) + grid(i,j).edge_lengths(2)/2;
            intervals = [grid(i,j).location(1) - grid(i,j).edge_lengths(1)/2, grid(i,j).location(1) + grid(i,j).edge_lengths(1)/2];
            grid(i,j).total_current(4) = gauss_kron(grid,i,j,y,[0,1],q,r_s,source_gp,nodes,weights,0,intervals,0.0,[],0.0,0,max_er,max_loc_er,max_divs);

            if ismember([i,j],source_gp,'rows')
                grid(i,j).avg_N_absorb = 2*pi/size(source_gp,1)*q - sum(grid(i,j).total_current.*[dy,dx,dy,dx]);
            else
                grid(i,j).avg_N_absorb = sum(-grid(i,j).total_current.*[dy,dx,dy,dx]);
            end

            grid(i,j).avg_flux = grid(i,j).avg_N_absorb/(prod(grid(i,j).edge_lengths)*grid(i,j).sigma_a);

            if rem(i,2) == 0.0
                fprintf(repmat('\b',1,s))
                s = fprintf('Percent Done: %%%.2f\n',i/num_zones(1)*100);
            end
        end
    end

    
    %this is mostly just the true solution function without the subdivision
    %so there are a lot of extra variables that arent used
    function total_current = gauss_kron(grid,i,j,xy,n,q,r_s,source_gp,nodes,...
            weights,bad_ints,ints,approx,prev_ints,prev_approx,divs,max_er,max_loc_er,max_divs)
        %intervals is updated to contain each of the different sub-intervals
        %approx is the solution for those intervals
        
        int1 = ints(1);
        int2 = ints(2);
        
        ints = linspace(int1,int2,max_divs+1);
        approx = zeros(max_divs,1);
        
        for m = 1:length(ints)-1
            sub_nodes = 1/2*(1+nodes)*(ints(m+1) - ints(m)) + ints(m);
            sub_weights = 1/2*weights*(ints(m+1) - ints(m));
            f_eval = zeros(1,length(sub_nodes));
            for k = 1:length(sub_nodes)
                if n(2) == 0 %if n is horiz, d is the x coord
                    r = [xy,sub_nodes(k)];
                else %if n is vert, d is the y coord
                    r = [sub_nodes(k),xy];
                end
                R = sqrt(sum((r-r_s).^2));
                sigma_bar = average_xs(r,r_s,source_gp,grid,i,j);
                f_eval(k) = q*exp(-sigma_bar*R)/R * dot(n,(r-r_s)/R);
            end
            approx(m) = sum(sub_weights.*f_eval);
        end
        
        total_current = sum(approx)/(ints(end)-ints(1));
    end
end

