function N_avg = avg_rays_per_zone(num_zones,N_rays,RT_meth)

total_rays = 0;

num_interior_zones = 0;
num_corner_zones = 0;
num_edge_zones = 0;

for i = 1:num_zones
    for j = 1:num_zones
        if strcmp(RT_meth,'surf') %for a source in a corner
            n = N_rays; %n is the number of rays per face
            %Interior zones
            if i ~= 1 && i ~= num_zones && j ~= 1 && j ~= num_zones
                %corners = number of corner rays / number of (active) faces sharing that ray
                corners = 4/4;
                edges = 2*(n-2);
                total_rays = total_rays + corners + edges;
                num_interior_zones = num_interior_zones + 1;
                
            %Corner zone (top right corner)
            elseif i == num_zones && j == num_zones
                corners = 1/2 + 2/3;
                edges = 2*(n-2);
                total_rays = total_rays + corners + edges;
                num_corner_zones = num_corner_zones + 1;            
                
            %Corner zone (top left or bottom right corner)
            elseif (i == num_zones && j == 1) || (i == 1 && j == num_zones)
                corners = 1 + 1/3 + 1/4;
                edges = 2*(n-2);
                total_rays = total_rays + corners + edges;
                num_corner_zones = num_corner_zones + 1;
                
            %Inner edge zones
            elseif i == 1 || j == 1
                corners = 1 + 2/4;
                edges = 2*(n-2);
                total_rays = total_rays + corners + edges;
                num_edge_zones = num_edge_zones + 1;
                
            %Far edge zones
            else
                corners = 2/3 + 1/4;
                edges = 2*(n-2);
                total_rays = total_rays + corners + edges;
                num_edge_zones = num_edge_zones + 1;            
            end
            
        elseif strcmp(RT_meth,'center')
            n = sqrt(N_rays);
            %Interior zones
            if i ~= 1 && i ~= num_zones && j ~= 1 && j ~= num_zones
                %corners = number of corner rays / number of zones sharing that ray
                corners = 4/4;
                edges = 4*(n-2)/2;
                interior = (n-2)^2;
                total_rays = total_rays + corners + edges + interior;
                num_interior_zones = num_interior_zones + 1;
                
            %Corner zones
            elseif (i == 1 || i == num_zones) && (j == 1 || j == num_zones)
                corners = 1 + 2/2 + 1/4;
                edges = 2*(n-2) + 2*(n-2)/2;
                interior = (n-2)^2;
                total_rays = total_rays + corners + edges + interior;
                num_corner_zones = num_corner_zones + 1;
                
            %Edge zones
            else
                corners = 2/2 + 2/4;
                edges = 1*(n-2) + 3*(n-2)/2;
                interior = (n-2)^2;
                total_rays = total_rays + corners + edges + interior;
                num_edge_zones = num_edge_zones + 1;
            end
        end
    end
end

N_avg = total_rays/num_zones^2;


%Add in a plot/table showing the limit of these - try to capture the work
%being done per zone count - the efficiency


