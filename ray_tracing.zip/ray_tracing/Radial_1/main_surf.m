clear

N_zones = 20;
N_quad = 4; 
quad_rule = 'Gauss';
%quad_rule = 'Gauss-Lobatto';
%quad_rule = 'Trapz';   %it would be better if this were a higher order method because the order of the method is locked, unlike the other methods
solver = 'solver_surf';
%solver = 'solver_surf_comp';
max_divs_comp = 3;
q = 1.0e6;
%q = 1;
%L = 0.1;
%H = 0.1;
L = 1.0;
H = 1.0;
%source_loc = [0.0,0.5];
source_loc = [0.5,0.5];
%source_loc = [0.0,0.0];

max_error = 1e-15;
max_divs = 20;
N_true = 3;
load_soln = 0;

neg_fix = 0;

global use_func, global deriv_flag
use_func = 0;
deriv_flag = 0;

wp = -1;
exclude = 20;
include_plots = 1;
save_plots = 0;

num_zones = [N_zones,N_zones];
dim = [L,H];

tic
fprintf('\n--------------------------------------------\n')
fprintf('\nSurface Method\n')
fprintf('\nTotal number of zones = %d\n',prod(num_zones))
fprintf('Number of zones per dimension = %d\n',N_zones)
fprintf('Number of rays per face = %.0f\n\n',N_quad)

warning('off','MATLAB:MKDIR:DirectoryExists')
warning('off','MATLAB:polyfit:RepeatedPointsOrRescale')

addpath(strcat(pwd,'\\Functions\\General_Functions'))
addpath(strcat(pwd,'\\Functions\\Case_Functions'))
addpath(strcat(pwd,'\\Functions\\Solvers'))

grid = looper(num_zones,dim,N_quad,q,source_loc,solver,quad_rule,neg_fix,max_divs_comp,max_error);

if load_soln == 1
    load(sprintf('.\\true_solutions\\true_soln__%d_zones.mat',num_zones(1)),'grid_true');
else
    grid_true = looper(num_zones,dim,N_true,q,source_loc,'solver_surf_adapt',quad_rule,neg_fix,max_divs,max_error);
end

[absorb_error_tot,absorb_error_avg,absorb_error_med,absorb_error_L1,absorb_error_L2,...
    absorb_error_L1_rem,absorb_error_L2_rem,leakage_error,cons_error,wp_rel_error,wp_L1] = ...
    plotter(grid,grid_true,q,source_loc,dim,N_quad,solver,include_plots,save_plots,exclude,wp);

rmpath(strcat(pwd,'\\Functions\\General_Functions'))
rmpath(strcat(pwd,'\\Functions\\Case_Functions'))
rmpath(strcat(pwd,'\\Functions\\Solvers'))

toc
fprintf('\n')

